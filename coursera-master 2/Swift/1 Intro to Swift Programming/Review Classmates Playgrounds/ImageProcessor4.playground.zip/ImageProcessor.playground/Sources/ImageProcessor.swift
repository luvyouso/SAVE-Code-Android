import UIKit

public class ImageProcessor {
    
    public static let BRIGHTNESS_RATIO_1_5X = BrightnessRatioFilter(ratio: 1.5)
    public static let BRIGHTNESS_RATIO_0_8X = BrightnessRatioFilter(ratio: 0.8)
    public static let BRIGHTNESS_OFFSET_30_PLUS = BrightnessOffsetFilter(offset: 30)
    public static let BRIGHTNESS_OFFSET_30_MINUS = BrightnessOffsetFilter(offset: -30)
    public static let CONTRAST_RATIO_1_5X = ContrastRatioFilter(ratio: 1.5)
    public static let CONTRAST_RATIO_0_8X = ContrastRatioFilter(ratio: 0.8)
    public static let CONTRAST_OFFSET_20_PLUS = ContrastOffsetFilter(offset: 20)
    public static let CONTRAST_OFFSET_20_MINUS = ContrastOffsetFilter(offset: -20)
    
    var filterList: [Filter]
    var params: [Int]
    var image: RGBAImage
    
    public init(image: RGBAImage) {
        
        self.filterList = []
        self.params = []
        self.image = image
        
        var totalRed = 0
        var totalGreen = 0
        var totalBlue = 0
        
        for y in 0..<image.height {
            for x in 0..<image.width {
                let idx = y * image.width + x
                let pixel = image.pixels[idx]
                totalRed += Int(pixel.red)
                totalGreen += Int(pixel.green)
                totalBlue += Int(pixel.blue)
            }
        }
        
        let pixelCount = image.width * image.height
        
        params.append(totalRed / pixelCount)
        params.append(totalGreen / pixelCount)
        params.append(totalBlue / pixelCount)
    }
    
    public func registerFilter(filter: Filter) {
        filterList.append(filter)
    }
    
    public func execute() -> UIImage {
        
        for filter in filterList {
            filter.apply(image, params: params)
        }
        return image.toUIImage()!
    }
}

