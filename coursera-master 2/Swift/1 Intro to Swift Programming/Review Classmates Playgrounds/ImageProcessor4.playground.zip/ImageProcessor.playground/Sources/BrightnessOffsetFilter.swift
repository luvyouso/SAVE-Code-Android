import UIKit

public class BrightnessOffsetFilter: Filter {
    
    var offset: Int
    
    required public init(offset: Int) {
        
        print("Initializing BrightnessOffsetFilter with offset=" + String(offset))
        self.offset = offset
    }
    
    override func convertPixel(pixel: Pixel, params: [Int]) -> Pixel {
        
        var newPixel = pixel
        let newRed = Int(pixel.red) + offset
        let newGreen = Int(pixel.green) + offset
        let newBlue = Int(pixel.blue) + offset
        newPixel.red = UInt8(max(min(newRed, 255), 0))
        newPixel.green = UInt8(max(min(newGreen, 255), 0))
        newPixel.blue = UInt8(max(min(newBlue, 255), 0))
        return newPixel
    }
}

