import UIKit

public class ContrastOffsetFilter: Filter {
    
    var offset: Int
    
    required public init(offset: Int) {
        
        print("Initializing ContrastOffsetFilter with offset=" + String(offset))
        self.offset = offset
    }
    
    override func convertPixel(pixel: Pixel, params: [Int]) -> Pixel {
        
        let avgR = params[0]
        let avgG = params[1]
        let avgB = params[2]
        
        let deltaR = Int(pixel.red) - avgR
        let deltaG = Int(pixel.green) - avgG
        let deltaB = Int(pixel.blue) - avgB
        
        var newPixel = pixel
        let newRed =  Int(pixel.red) + offset * (deltaR > 0 ? 1 : -1)
        let newGreen =  Int(pixel.green) + offset * (deltaG > 0 ? 1 : -1)
        let newBlue =  Int(pixel.blue) + offset * (deltaB > 0 ? 1 : -1)
        
        newPixel.red = UInt8(max(min(newRed, 255), 0))
        newPixel.green = UInt8(max(min(newGreen, 255), 0))
        newPixel.blue = UInt8(max(min(newBlue, 255), 0))
        return newPixel
    }
}