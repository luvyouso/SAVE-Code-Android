import UIKit

public class ContrastRatioFilter: Filter {
    
    var ratio: Float
    
    required public init(ratio: Float) {
        
        print("Initializing ContrastRatioFilter with ratio=" + String(ratio))
        self.ratio = ratio
    }
    
    override func convertPixel(pixel: Pixel, params: [Int]) -> Pixel {
        
        let avgR = params[0]
        let avgG = params[1]
        let avgB = params[2]
        
        let deltaR = Int(pixel.red) - avgR
        let deltaG = Int(pixel.green) - avgG
        let deltaB = Int(pixel.blue) - avgB
        
        var newPixel = pixel
        let newRed =  Int(pixel.red) + Int(Float(deltaR) * ratio)
        let newGreen =  Int(pixel.green) + Int(Float(deltaG) * ratio)
        let newBlue =  Int(pixel.blue) + Int(Float(deltaB) * ratio)
        
        newPixel.red = UInt8(max(min(newRed, 255), 0))
        newPixel.green = UInt8(max(min(newGreen, 255), 0))
        newPixel.blue = UInt8(max(min(newBlue, 255), 0))
        return newPixel
    }
}