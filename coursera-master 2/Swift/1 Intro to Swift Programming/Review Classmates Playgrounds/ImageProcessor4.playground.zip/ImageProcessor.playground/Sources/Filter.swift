import UIKit

public class Filter {
    
    public func apply(image: RGBAImage, params: [Int]) {
        
        print("Applying filter=" + String(self) + " to image")
        for y in 0..<image.height {
            for x in 0..<image.width {
                let idx = y * image.width + x
                let pixel = convertPixel(image.pixels[idx], params: params)
                image.pixels[idx] = pixel
            }
        }
    }
    
    func convertPixel(pixel: Pixel, params: [Int]) -> Pixel {

        return pixel;
    }
}

