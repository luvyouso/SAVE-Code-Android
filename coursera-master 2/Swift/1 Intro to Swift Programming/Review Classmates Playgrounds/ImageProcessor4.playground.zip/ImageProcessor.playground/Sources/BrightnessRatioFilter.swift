import UIKit

public class BrightnessRatioFilter: Filter {
    
    var ratio: Float
    
    required public init(ratio: Float) {
        
        print("Initializing BrightnessRatioFilter with ratio=" + String(ratio))
        self.ratio = ratio
    }
    
    override func convertPixel(pixel: Pixel, params: [Int]) -> Pixel {
        
        var newPixel = pixel
        let newRed = Int(Float(pixel.red) * ratio)
        let newGreen = Int(Float(pixel.green) * ratio)
        let newBlue = Int(Float(pixel.blue) * ratio)
        newPixel.red = UInt8(max(min(newRed, 255), 0))
        newPixel.green = UInt8(max(min(newGreen, 255), 0))
        newPixel.blue = UInt8(max(min(newBlue, 255), 0))
        return newPixel
    }
}