//: Playground - noun: a place where people can play

import UIKit

let image = UIImage(named: "sample")!

// Process the image!
let rgbaImage = RGBAImage(image: image)!

let processor = ImageProcessor(image: rgbaImage)
processor.registerFilter(ImageProcessor.CONTRAST_OFFSET_20_MINUS)
processor.registerFilter(ImageProcessor.CONTRAST_RATIO_1_5X)
processor.registerFilter(ImageProcessor.BRIGHTNESS_OFFSET_30_MINUS)
processor.registerFilter(ImageProcessor.BRIGHTNESS_RATIO_1_5X)
processor.registerFilter(ImageProcessor.BRIGHTNESS_OFFSET_30_PLUS)

let newImage = processor.execute()
