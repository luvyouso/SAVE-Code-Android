//: ## Coursera Swift Class - Week 5 Assignment
//: Author: Fouad HAMDI - October 2015

import UIKit

//:
//: ### The image before processing
//:
let image = UIImage(named: "sample")!


//:
//: ## Basic Usage Example
//:
//: After instantiating the image processor, we use the appendFilter method to define the pipeline we
//: would like to apply: the processor will apply the filters in the order they are chained.
//:
//: Each filter has its own parameters.
//:
//: Then, we execute the apply() method to get the processed image.
//:
//: note: If you don't see the image, please click on the + button at the right of the playground.
//:

ImageProcessor()
  .appendFilter(GaussianBlurFilter())
  .appendFilter(ContrastLevelFilter(level: 45))
  .appendFilter(BrightnessLevelFilter(level: 22))
  .appendFilter(GreyscaleFilter())
  .appendFilter(ContrastLevelFilter(level: -19))
  .apply(image)

//:
//: ## Usage of more meaningful methods to define the pipeline.
//:
//: This example has the same effect than the previous one but is a more elegant usage.
ImageProcessor()
  .blur()
  .contrast(withLevel: 45)
  .brightness(withLevel: 22)
  .greyscale()
  .contrast(withLevel: -19)
  .apply(image)


//:
//: ## Usage of predefined filters.
//:
//: The ImageProcessor API defines pre-defined filters which can be chained.
//:
ImageProcessor()
  .highContrast()
  .highContrast()
  .brightness50()
  .blur()
  .apply(image)

//:
//: ## Usage of predefined filters by their name to define the pipeline.
//:
//: You can use predefined names to chain filters.
//:
//: To know the available list of names, use imageProcessor.predefinedFiltersNames
//:
ImageProcessor().predefinedFiltersNames

ImageProcessor()
  .appendFilter(withName: "High Contrast")
  .appendFilter(withName: "High Contrast")
  .appendFilter(withName: "50% Brightness")
  .appendFilter(withName: "Blur")
  .apply(image)

//:
//: ## Apply a single predefined filter by its name.
//:
ImageProcessor().applyFilter(withName: "High Contrast", to: image)

//:
//: ## Using an initializer.
//:
//: It is also possible to define directly an array of filters to use to the processor.
let filters:[Filter] = [GreyscaleFilter(), ContrastLevelFilter(level: 100)]
ImageProcessor(withFilters: filters)
  .apply(image)


