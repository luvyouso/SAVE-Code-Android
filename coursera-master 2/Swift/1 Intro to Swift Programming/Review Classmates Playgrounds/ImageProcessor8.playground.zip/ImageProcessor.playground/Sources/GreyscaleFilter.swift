//:
//: Greyscale filter.
//:
//: See (http://www.dfstudios.co.uk/articles/programming/image-programming-algorithms/image-processing-algorithms-part-3-greyscale-conversion/)
//:
//: Author: Fouad HAMDI - October 2015
public class GreyscaleFilter : BaseFilter, Filter {
  //: Default initializer.
  public override init() {}
  
  //: Apply the greyscale filter to the three channels.
  private func applyGreyscaleFormula(red red: UInt8, green: UInt8, blue: UInt8) -> UInt8 {
    return UInt8(0.299*Double(red) + 0.587*Double(green) + 0.114*Double(blue))
  }
  
  //: Apply the filter to the pixel of an image.
  override func apply(x x: Int, y: Int, toImage rgbaImage: RGBAImage) -> Pixel {
    let pixelIndex = y * rgbaImage.width + x
    var pixel = rgbaImage.pixels[pixelIndex]
    let computation = applyGreyscaleFormula(red: pixel.red, green: pixel.green, blue: pixel.blue)
    pixel.red = computation
    pixel.green = computation
    pixel.blue = computation
    return pixel
  }
}