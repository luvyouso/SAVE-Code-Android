//:
//: # Blur Filter
//:
//: It can be initialized with 3x3 kernel only. If none is provided, a 100% default kernel is used.
//:
//: Inspired from (https://www.youtube.com/watch?v=7LW_75E3A1Q)
//:
//: Author: Fouad HAMDI - October 2015
public class GaussianBlurFilter : BaseFilter, Filter {
  let kernel:[[Double]]
  let defaultKernel = [[1.0, 1.0, 1.0],[1.0, 1.0, 1.0],[1.0, 1.0, 1.0]]
  
  //: Initialize the filter with a 3x3 kernel
  public init(withKernel kernel: [[Double]]) {
    if kernel.count != 3 || kernel[0].count != 3 {
      print("Invalid kernel: the default one will be used.")
      self.kernel = defaultKernel
    } else {
      self.kernel = kernel
    }
  }
  
  //: Default initializer.
  public override init() {
    self.kernel = defaultKernel
  }
  
  //: Apply the gaussian blur effect.
  override func apply(x x: Int, y: Int, toImage rgbaImage: RGBAImage) -> Pixel {
    let pixelIndex = y * rgbaImage.width + x
    
    //: we extract the neighbours around the pixel to transform.
    let topLeftPixelIndex = x > 0 && y > 0 ? (y - 1) * rgbaImage.width + (x + 1) : pixelIndex
    let topMiddlePixelIndex = y > 0 ? (y - 1) * rgbaImage.width + x : pixelIndex
    let topRightPixelIndex = x < rgbaImage.width && y > 0 ? (y - 1) * rgbaImage.width + (x - 1) : pixelIndex
    let rightPixelIndex =  x < rgbaImage.width ? y * rgbaImage.width + (x + 1) : pixelIndex
    let leftPixelIndex =  x > 0 ? y * rgbaImage.width + (x - 1) : pixelIndex
    let bottomLeftPixelIndex = x > 0 && y < rgbaImage.height ? (y + 1) * rgbaImage.width + (x + 1) : pixelIndex
    let bottomMiddlePixelIndex = y < rgbaImage.height ? (y + 1) * rgbaImage.width + x : pixelIndex
    let bottomRightPixelIndex = x < rgbaImage.width && y < rgbaImage.height ? (y + 1) * rgbaImage.width + (x - 1) : pixelIndex

    let topLeft = rgbaImage.pixels[topLeftPixelIndex]
    let topMiddle = rgbaImage.pixels[topMiddlePixelIndex]
    let topRight = rgbaImage.pixels[topRightPixelIndex]

    let left = rgbaImage.pixels[rightPixelIndex]
    var middle = rgbaImage.pixels[pixelIndex]
    let right = rgbaImage.pixels[leftPixelIndex]
    
    let bottomLeft = rgbaImage.pixels[bottomLeftPixelIndex]
    let bottomMiddle = rgbaImage.pixels[bottomMiddlePixelIndex]
    let bottomRight = rgbaImage.pixels[bottomRightPixelIndex]

    //: we average the values of each channel to compute the new pixel value.
    let total:UInt8 = 9
    
    // red channel
    middle.red = truncate(
          (Double(topLeft.red)*kernel[0][0] + Double(topMiddle.red)*kernel[0][1] + Double(topRight.red)*kernel[0][2] + // top
          Double(left.red)*kernel[1][0] + Double(middle.red)*kernel[1][1] + Double(right.red)*kernel[1][1] + // middle
          Double(bottomLeft.red)*kernel[2][0] + Double(bottomMiddle.red)*kernel[2][1] + Double(bottomRight.red)*kernel[2][2]) // bottom
            / Double(total))  // average
    
    // green channel
    middle.green = truncate(
      (Double(topLeft.green)*kernel[0][0]  + Double(topMiddle.green)*kernel[0][1] + Double(topRight.green)*kernel[0][2] + // top
      Double(left.green)*kernel[1][0] + Double(middle.green)*kernel[1][1] + Double(right.green)*kernel[1][2] +    // middle
      Double(bottomLeft.green)*kernel[2][0] + Double(bottomMiddle.green)*kernel[2][1] + Double(bottomRight.green)*kernel[2][2])  //bottom
        / Double(total))
    
    // blue channel
    middle.blue = truncate(
      (Double(topLeft.blue)*kernel[0][0] + Double(topMiddle.blue)*kernel[0][1] + Double(topRight.blue)*kernel[0][2] + // top
       Double(left.blue)*kernel[1][0] + Double(middle.blue)*kernel[1][1] + Double(right.blue)*kernel[1][2] + // middle
      Double(bottomLeft.blue)*kernel[2][0] + Double(bottomMiddle.blue)*kernel[2][1] + Double(bottomRight.blue)*kernel[2][2]) // bottom
        / Double(total))
    
    return middle
  }
}