//:
//: # Protocol for the filters.
//:
//: Author: Fouad HAMDI - October 2015
public protocol Filter {
  //:
  //: Apply the filter to the specified image and return the filtered image.
  //:
  func apply(toImage rgbaImage: RGBAImage) -> RGBAImage;
}

//:
//: Utility class for the filters.
//:
public class BaseFilter {
   //: Utility method to ensure the channels values are between 0 and 255.
  func truncate(number: Double) -> UInt8 {
    return UInt8(max(0, min(255, number)))
  }
  
  //: Apply the filter to the specified pixel of the image.
  //:
  //: TO BE IMPLEMENTED IN THE SUBCLASSES. BY DEFAULT, NOTHING IS DONE TO THE IMAGE.
  func apply(x x: Int, y: Int, toImage rgbaImage: RGBAImage) -> Pixel {
    let index = y * rgbaImage.width + x
    return rgbaImage.pixels[index]
  }
  
  //: Apply the filter to the image.
  public func apply(toImage rgbaImage: RGBAImage) -> RGBAImage {
    for y in 0..<rgbaImage.height {
      for x in 0..<rgbaImage.width {
        let index = y * rgbaImage.width + x
        rgbaImage.pixels[index] = apply(x: x, y: y, toImage: rgbaImage)
      }
    }
    return rgbaImage
  }
}