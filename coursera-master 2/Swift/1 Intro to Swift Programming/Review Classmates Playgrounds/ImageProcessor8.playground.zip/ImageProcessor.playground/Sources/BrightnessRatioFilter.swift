//:
//: Filter that can be used to increase or decrease the brightness of an image.
//:
//: Initialize it with a brightness ratio value between 0 and 1.
//:
//: Author: Fouad HAMDI - October 2015
public class BrightnessRatioFilter : BaseFilter, Filter {
  //: The level of brightness to apply to the image.
  private let ratio: Double
  
  //: Initialize the filter with a ratio.
  public init(ratio: Double) {
    if ratio >= 0 && ratio <= 1 {
      self.ratio = ratio
    } else {
      print("Invalid ratio provided: we initialize it with 0 value.")
      self.ratio = 0
    }
  }
  
  //: Apply the brightness to a channel.
  private func applyBrightness(channel: UInt8) -> UInt8 {
    return truncate(Double(channel) * ratio + Double(channel))
  }
  
  //: Apply the brightness to an image pixel.
  override func apply(x x: Int, y: Int, toImage rgbaImage: RGBAImage) -> Pixel {
    let pixelIndex = y * rgbaImage.width + x
    var pixel = rgbaImage.pixels[pixelIndex]
    pixel.red = applyBrightness(pixel.red)
    pixel.green = applyBrightness(pixel.green)
    pixel.blue = applyBrightness(pixel.blue)
    return pixel
  }
}