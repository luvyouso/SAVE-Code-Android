//:
//: Image processor which is able to apply a pipeline of filters.
//:
//: Author: Fouad HAMDI - October 2015
import UIKit

public class ImageProcessor {
  //: The filters to apply.
  private var filters: [Filter]
  
  //: The list of predefined filters.
  public enum FilterName : String {
    case HighContrast = "High Contrast"
    case HighBrightness = "50% Brightness"
    case Blur = "Blur"
    case NegativeContrast = "Negative Contrast"
    case Greyscale = "Greyscale"
    
    static let allValues = [HighContrast.rawValue, HighBrightness.rawValue, Blur.rawValue, NegativeContrast.rawValue, Greyscale.rawValue]
  }
  
  
  //: Default initializer
  public init() {
    self.filters = []
  }
  
  //: Initializer with filters list.
  public init(withFilters filters: [Filter]) {
    self.filters = filters
  }
  
  //: Add a filter to the processor.
  public func appendFilter(filter: Filter) -> ImageProcessor {
    filters.append(filter)
    return self
  }
  
  //: Add a predefined filter to the processor.
  public func appendFilter(withName name: String) -> ImageProcessor {
    if let filterName = FilterName(rawValue: name) {
      switch filterName {
      case .HighContrast:
        self.highContrast()
      case .HighBrightness:
        self.brightness50()
      case .Blur:
        self.blur()
      case .NegativeContrast:
        self.contrast(withLevel: -128)
      case .Greyscale:
        self.greyscale()
      }
    }
    return self
  }
  
  //: Return the list of predefined filters names.
  public var predefinedFiltersNames:[String] {
    get {
      return FilterName.allValues
    }
  }
  
  //: Applies the registered filters to the specified image.
  public func apply(image: UIImage) -> UIImage? {
    var rgbaImage = RGBAImage(image: image)!
    for filter in self.filters {
      rgbaImage = filter.apply(toImage: rgbaImage)
    }
    return rgbaImage.toUIImage()
  }
  
  //: Append a high contrast filter to the filters list.
  public func highContrast() -> ImageProcessor {
    return appendFilter(ContrastLevelFilter(level: 128))
  }
  
  //: Add a blur filter to the process.
  public func blur() -> ImageProcessor {
    return appendFilter(GaussianBlurFilter())
  }
  
  //: Add a blur filter initialized with the specified kernel to the processor.
  public func blur(withKernel kernel: [[Double]]) -> ImageProcessor {
    return appendFilter(GaussianBlurFilter(withKernel: kernel))
  }
  
  //: Add a 50% brightness filter.
  public func brightness50() -> ImageProcessor {
    return appendFilter(BrightnessRatioFilter(ratio: 0.5))
  }
  
  //: Add a contrast filter.
  public func contrast(withLevel level: Int) -> ImageProcessor {
    return appendFilter(ContrastLevelFilter(level: level))
  }
  
  //: Add a brightness filter.
  public func brightness(withLevel level: Int) -> ImageProcessor {
    return appendFilter(BrightnessLevelFilter(level: level))
  }
  
  //: Add a brightness filter.
  public func brightness(withRatio ratio: Double) -> ImageProcessor {
    return appendFilter(BrightnessRatioFilter(ratio: ratio))
  }
  
  //: Add a greyscale filter.
  public func greyscale() -> ImageProcessor {
    return appendFilter(GreyscaleFilter())
  }
  
  //: Add the specified filter and execute the process.
  //: Any existing filter will be removed.
  public func applyFilter(withName name: String, to image: UIImage) -> UIImage? {
    self.filters  = []
    return appendFilter(withName: name).apply(image)
  }
}