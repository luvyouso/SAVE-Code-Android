//: Filter that can be used to increase or decrease the brightness of an image.
//:
//: Initialize it with a brightness level value between -255 and 255.
//: see (http://www.dfstudios.co.uk/articles/programming/image-programming-algorithms/image-processing-algorithms-part-4-brightness-adjustment/)
//
//: Author: Fouad HAMDI - October 2015
public class BrightnessLevelFilter : BaseFilter, Filter {
  //: The level of brightness to apply to the image.
  private let level: Int
  
  //: initialize the filter with the level of brightness wanted.
  public init(level: Int) {
    self.level = level
  }
  
  //: helper function to apply the brightness to a channel.
  private func applyBrightness(channel: UInt8) -> UInt8 {
    return truncate(Double(channel) + Double(self.level))
  }
  
  //: Apply the brightness filter to the specified pixel of the image.
  override func apply(x x: Int, y: Int, toImage rgbaImage: RGBAImage) -> Pixel {
    let pixelIndex = y * rgbaImage.width + x
    var pixel = rgbaImage.pixels[pixelIndex]
    pixel.red = applyBrightness(pixel.red)
    pixel.green = applyBrightness(pixel.green)
    pixel.blue = applyBrightness(pixel.blue)
    return pixel
  }
}