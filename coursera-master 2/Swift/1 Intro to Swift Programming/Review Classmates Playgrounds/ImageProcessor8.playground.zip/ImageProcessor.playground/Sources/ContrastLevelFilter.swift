//:
//: Filter that can be used to enhance the contrast of an image.
//:
//: Initialize it with a contrast level value between -255 and 255.
//:
//: @see (http://www.dfstudios.co.uk/articles/programming/image-programming-algorithms/image-processing-algorithms-part-5-contrast-adjustment/)
//:
//: Author: Fouad HAMDI - October 2015
public class ContrastLevelFilter : BaseFilter, Filter {
  //: Contrast level. Value between -255 and +255.
  private let level: Int
  
  //: Initialize the filter with a level.
  public init(level: Int) {
    if level >= -255 && level <= 255 {
      self.level = level
    } else {
      print("Invalid contrast level provided: we will use 0")
      self.level = 0
    }
  }
  
  //: Return the correction factor computed from the contrast level.
  private lazy var correctionFactor:Double = {
    return Double(259 * (self.level + 255)) / Double(255 * (259 - self.level))
    }()
  
  //: Apply the contrast filter to a channel.
  private func applyContrastOn(channel channel: UInt8) -> UInt8 {
    return truncate(self.correctionFactor * (Double(channel) - 128) + 128)
  }
  
  //: Apply the contrast channel to a pixel.
  override func apply(x x: Int, y: Int, toImage rgbaImage: RGBAImage) -> Pixel {
    let pixelIndex = y * rgbaImage.width + x
    var pixel = rgbaImage.pixels[pixelIndex]
    pixel.red = applyContrastOn(channel: pixel.red)
    pixel.green = applyContrastOn(channel: pixel.green)
    pixel.blue = applyContrastOn(channel: pixel.blue)
    
    return pixel
  }
}