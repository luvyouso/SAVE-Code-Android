//: Playground - noun: a place where people can play

import UIKit

let image = UIImage(named: "sample")!

// Process the image!

// The image processor class accepts an image and 
// can return a new image with filters applied

class ImageProcessor {
    var rgbImage: RGBAImage

    init(image: UIImage) {
        self.rgbImage = RGBAImage(image: image)!
    }

    // Apply a list of filters in sequence and return a new image
    func applyFilter(filterList: [Filter]) -> UIImage? {
        for var i = 0; i < rgbImage.pixels.count; i++ {
            var color = self.rgbImage.pixels[i]
            for filter in filterList {
                color = filter.pixelProcess(color)
            }
            self.rgbImage.pixels[i] = color
        }
        return self.rgbImage.toUIImage()
    }
    
    // Predefined filters that can be a combination of other filters
    func createWithFilter(name: String) -> UIImage? {
        switch (name) {
            case "Night":
                return applyFilter([Night()])
            case "Sepia":
                return applyFilter([Sepia()])
            case "BlackAndWhite":
                return applyFilter([BlackAndWhite()])
            case "Damaged":
                return applyFilter([LeftPhotoOnTheDashOfTheCarForTooLong(), SurfaceOfTheSun()])
            case "ExtremeYellow":
                return applyFilter([Night(), SurfaceOfTheSun()])
        default:
            return self.rgbImage.toUIImage()
        }
    }
}


// Base filter class does nothing to pixels by default
class Filter {
    
    func pixelProcess(p: Pixel) -> Pixel {
        return p
    }
    
    
    // Filter processing that makes a pixel gray with brightness factor
    func makeMoreGray(p: Pixel, brightness: Double) -> Pixel {
        var averageValue = (Double(p.red) + Double(p.green) + Double(p.blue)) / 3 * brightness
        if (averageValue > 255) {
            averageValue = 255
        }
        let average = UInt8(averageValue)
    
        var result: Pixel = p
    
        result.red = average
        result.green = average
        result.blue = average
    
        return result;
    }
    
    // Increased red and green to make the pixel appear more yellow
    func makeMoreYellow(p: Pixel, yellowness: Double) -> Pixel {
        var averageValue = (Double(p.red) + Double(p.green)) / 2 * yellowness
        if (averageValue > 255) {
            averageValue = 255
        }
        let average = UInt8(averageValue)
        
        var result = p
        result.red = average
        result.green = average
        return result
    }
    
}


// Predefined Filter Classes with combination of operations
class Night: Filter {
    override func pixelProcess(p: Pixel) -> Pixel {
        return makeMoreGray(p, brightness: 0.3)
    }
}

class Sepia: Filter {
    override func pixelProcess(p: Pixel) -> Pixel {
        let color = makeMoreGray(p, brightness: 0.7)
        return makeMoreYellow(color, yellowness: 2)
    }
}

class SurfaceOfTheSun: Filter {
    override func pixelProcess(p: Pixel) -> Pixel {
        return makeMoreYellow(p, yellowness: 5)
    }
}

class BlackAndWhite: Filter {
    override func pixelProcess(p: Pixel) -> Pixel {
        return makeMoreGray(p, brightness: 1.0)
    }
}

class LeftPhotoOnTheDashOfTheCarForTooLong: Filter {
    override func pixelProcess(p: Pixel) -> Pixel {
        return makeMoreYellow(p, yellowness: 1.05)
    }
}

let img = ImageProcessor(image: image)
img.createWithFilter("Sepia")

