import Foundation
import UIKit

public struct ImageProcessor {
    public var rgbaImage: RGBAImage
    public var totalRed = 0
    public var totalGreen = 0
    public var totalBlue = 0
    public var pixelCount = 0
    public var averageRed = 0
    public var averageGreen = 0
    public var averageBlue = 0
    public var averageSum = 0
    
    
    public init?(image: UIImage) {
        rgbaImage = RGBAImage(image: image)!
        
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                
                let index = y * rgbaImage.width + x
                let pixel = rgbaImage.pixels[index]
                
                totalRed += Int(pixel.red)
                totalGreen += Int(pixel.green)
                totalBlue += Int(pixel.blue)
            }
        }
        
        pixelCount = rgbaImage.width * rgbaImage.height
        averageRed = totalRed / pixelCount
        averageGreen = totalGreen / pixelCount
        averageBlue = totalBlue / pixelCount
        averageSum = averageRed + averageGreen + averageBlue
        
    }
    
    public enum FilterType {
        case Sepia
        case Greyscale
        case Brightness
        case InvertColors
        case Opacity
    }
    
    
    public func increaseBrightness() -> UIImage {
        
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                
                let index = y * rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                
                let redDelta = Int(pixel.red) - averageRed
                let greenDelta = Int(pixel.green) - averageGreen
                let blueDelta = Int(pixel.blue) - averageBlue
                
                var defaultModifier = 5
                if (Int(pixel.red) + Int(pixel.green) + Int(pixel.blue) > averageSum){
                    defaultModifier = 2
                }
                
                pixel.red = UInt8(max(min(255, averageRed + defaultModifier * redDelta), 0))
                pixel.green = UInt8(max(min(255, averageGreen + defaultModifier * greenDelta), 0))
                pixel.blue = UInt8(max(min(255, averageBlue + defaultModifier * blueDelta), 0))
                rgbaImage.pixels[index] = pixel
                
            }
        }
        
        return rgbaImage.toUIImage()!
    }
    
    
    public func makeTransparent() -> UIImage {
        
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                
                let index = y * rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                
                pixel.alpha = UInt8(max(min(255, Double(pixel.alpha) * 0.70), 0))
                rgbaImage.pixels[index] = pixel
                
            }
        }
        
        return rgbaImage.toUIImage()!
    }
    
    public func convertToSepia() -> UIImage {
        
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                
                let index = y * rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                
                let outputRed = (Double(pixel.red) * 0.393) + (Double(pixel.green) * 0.769) + (Double(pixel.blue) * 0.189)
                
                let outputGreen = (Double(pixel.red) * 0.346) + (Double(pixel.green) * 0.686) + (Double(pixel.blue) * 0.168)
                let outputBlue = (Double(pixel.red) * 0.272) + (Double(pixel.green) * 0.534) + (Double(pixel.blue) * 0.131)
                
                pixel.red = UInt8(max(min(255, outputRed), 0))
                pixel.green = UInt8(max(min(255, outputGreen), 0))
                pixel.blue = UInt8(max(min(255, outputBlue), 0))
                
                
                rgbaImage.pixels[index] = pixel
                
            }
        }
        
        return rgbaImage.toUIImage()!
    }
    
    public func convertToGreyscale() -> UIImage {
        
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                
                let index = y * rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                
                let outputRed = (Double(pixel.red) * 0.2989) + (Double(pixel.green) * 0.5870) + (Double(pixel.blue) * 0.1140)
                let outputGreen = (Double(pixel.red) * 0.2989) + (Double(pixel.green) * 0.5870) + (Double(pixel.blue) * 0.1140)
                let outputBlue = (Double(pixel.red) * 0.2989) + (Double(pixel.green) * 0.5870) + (Double(pixel.blue) * 0.1140)
                
                pixel.red = UInt8(max(min(255, outputRed), 0))
                pixel.green = UInt8(max(min(255, outputGreen), 0))
                pixel.blue = UInt8(max(min(255, outputBlue), 0))
                
                
                rgbaImage.pixels[index] = pixel
                
            }
        }
        
        return rgbaImage.toUIImage()!
    }
    
    public func invert() -> UIImage {
        
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                
                let index = y * rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                
                let redDelta = 255 - Int(pixel.red)
                let greenDelta = 255 - Int(pixel.green)
                let blueDelta = 255 - Int(pixel.blue)
                
                pixel.red = UInt8(max(min(255, redDelta), 0))
                pixel.green = UInt8(max(min(255, greenDelta), 0))
                pixel.blue = UInt8(max(min(255, blueDelta), 0))
                rgbaImage.pixels[index] = pixel
                
            }
        }
        
        return rgbaImage.toUIImage()!
    }
    
    public func applyFilter(filter: FilterType) -> UIImage {
    
        switch filter {
        case FilterType.Sepia:
            return self.convertToSepia()
        case FilterType.Greyscale:
            return self.convertToGreyscale()
        case FilterType.Brightness:
            return self.increaseBrightness()
        case FilterType.InvertColors:
            return self.invert()
        case FilterType.Opacity:
            return self.makeTransparent()
        }
    }
    
    /* public func applyFilterChain(filters: [String]) -> UIImage {
        
        return applyFilter(filter: ImageProcessor.FilterType)
    } */

    
}
