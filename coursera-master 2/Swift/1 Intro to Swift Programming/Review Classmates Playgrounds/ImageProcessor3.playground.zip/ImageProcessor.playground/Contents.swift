//: Playground - noun: a place where people can play

import UIKit

let image = UIImage(named: "sample")!

// Process the image!

let imageProcessor = ImageProcessor(image: image)!


//let newImage1a = imageProcessor.makeTransparent()

let newImage1 = imageProcessor.applyFilter(ImageProcessor.FilterType.Opacity)

//let newImage2 = imageProcessor.convertToSepia()
let newImage2 = imageProcessor.applyFilter(ImageProcessor.FilterType.Sepia)


//let newImage3 = imageProcessor.convertToGreyscale()
let newImage3 = imageProcessor.applyFilter(ImageProcessor.FilterType.Greyscale)

//let newImage4 = imageProcessor.increaseBrightness()
let newImage4 = imageProcessor.applyFilter(ImageProcessor.FilterType.Brightness)

//let newImage5 = imageProcessor.invert()
let newImage5 = imageProcessor.applyFilter(ImageProcessor.FilterType.InvertColors)



