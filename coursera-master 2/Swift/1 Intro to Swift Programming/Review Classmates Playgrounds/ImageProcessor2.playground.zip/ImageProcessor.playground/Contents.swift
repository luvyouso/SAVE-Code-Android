//: Playground - noun: a place where people can play

import UIKit

let image = UIImage(named: "sample")!


// Process the image!

// I commented out the following code to let it run faster. The calculated average values are below
//let pixelCount = rgbaImage.width * rgbaImage.height
//var totalRed = 0
//var totalGreen = 0
//var totalBlue = 0
//
//for y in 0..<rgbaImage.height {
//    for x in 0..<rgbaImage.width {
//        let index = y * rgbaImage.width + x
//        let pixel = rgbaImage.pixels[index]
//
//        totalRed += Int(pixel.red)
//        totalGreen += Int(pixel.green)
//        totalBlue += Int(pixel.blue)
//    }
//}
//let avgRed = totalRed / pixelCount
//let avgGreen = totalGreen / pixelCount
//let avgBlue = totalBlue / pixelCount

// These were the calculated averages for red, green and blue:
let avgRed = 118
let avgGreen = 98
let avgBlue = 83
let avgSum = avgRed + avgGreen + avgBlue



protocol ImageProcessor {
    func Filter(filtername: String, value:Int?, filtercolor:String?) -> FilteredImage
}

// Brightness filter function
func brightness(inputimage: RGBAImage, value: Int) -> RGBAImage {
    let resultImage = inputimage
    
    for y in 0..<inputimage.height {
        for x in 0..<inputimage.width {
            let index = y * inputimage.width + x
            
            var pixel = inputimage.pixels[index]
            
            pixel.red = UInt8(max(min(255, Int(pixel.red) + value), 0))
            pixel.green = UInt8(max(min(255, Int(pixel.green) + value), 0))
            pixel.blue = UInt8(max(min(255, Int(pixel.blue) + value), 0))
            
            resultImage.pixels[index] = pixel
        }
    }
    return resultImage
}

// Contrast filter function
func contrast(inputimage: RGBAImage, value: Int) -> RGBAImage {
    let resultImage = inputimage
    
    for y in 0..<inputimage.height {
        for x in 0..<inputimage.width {
            let index = y * inputimage.width + x
    
            var pixel = inputimage.pixels[index]
    
            if (Int(pixel.red) + Int(pixel.green) + Int(pixel.blue) < avgSum) {
                pixel.red = UInt8(max(min(255, Int(pixel.red) - value), 0))
                pixel.green = UInt8(max(min(255, Int(pixel.green) - value), 0))
                pixel.blue = UInt8(max(min(255, Int(pixel.blue) - value), 0))
            } else {
                pixel.red = UInt8(max(min(255, Int(pixel.red) + value), 0))
                pixel.green = UInt8(max(min(255, Int(pixel.green) + value), 0))
                pixel.blue = UInt8(max(min(255, Int(pixel.blue) + value), 0))
            }
                resultImage.pixels[index] = pixel
        }
    }
    return resultImage
}

// Color filter function
// call with parameters "red", "green" or "blue" - it will turn the image red, green or blue (it sets the other 2 colors 0)
func color(inputimage: RGBAImage, color: String?=nil) -> RGBAImage {
    let resultImage = inputimage
    
    for y in 0..<inputimage.height {
        for x in 0..<inputimage.width {
            let index = y * inputimage.width + x
            
            var pixel = inputimage.pixels[index]
            if let effectivecolor = color {  // if the color parameter was not nil
                switch (effectivecolor) {
                    case "red":
                        pixel.green = 0
                        pixel.blue = 0
                    case "green":
                        pixel.red = 0
                        pixel.blue = 0
                    case "blue":
                        pixel.red = 0
                        pixel.green = 0
                    default:                 // default colro will be red
                        pixel.green = 0
                        pixel.blue = 0
                }
            } else {                         // if no parameter was specified for color, we turn it to default color (red)
                pixel.green = 0
                pixel.blue = 0
            }
            resultImage.pixels[index] = pixel
        }
    }
    return resultImage
}

// FilteredImage class that implements the ImageProcessor protocol - this will hold an image and have a customizable filter function - it will allos applying multiple filters in a chain
class FilteredImage: ImageProcessor {
    var image: RGBAImage
    init(image: RGBAImage) {
        self.image = image
    }
    func Filter(filtername: String, value:Int?=30, filtercolor:String?="") -> FilteredImage {
        switch (filtername) {
            case "brightness":
                if let effectivevalue = value {
                    self.image = brightness(self.image, value: effectivevalue)
                } else {
                    self.image = brightness(self.image, value: 100)  // default value for brightness
                }
            case "contrast":
                if let effectivevalue = value {
                    self.image = contrast(self.image, value: effectivevalue)
                } else {
                    self.image = contrast(self.image, value: 30)     // default value for contrast
                }
            case "color":
                self.image = color(self.image, color: filtercolor)
//            case "invert":
//                self.image = invert(self.image)
            default: break
        }
        return self
    }
}

let rgbaImage = RGBAImage(image: image)!
let filteredImage = FilteredImage(image: rgbaImage)

let filteredImage1 = filteredImage.Filter("contrast") // it will calculate contrast with default value 30
let newImage1 = filteredImage1.image.toUIImage()!

let filteredImage2 = filteredImage1.Filter("brightness", value: 100)
let newImage2 = filteredImage2.image.toUIImage()!

let filteredImage3 = filteredImage2.Filter("color", filtercolor: "green")
let newImage3 = filteredImage3.image.toUIImage()!


// The filters can also be applied in a chain (pipeline of filters) like this:
// Let's start from the original image first, since that was changed by the previous filters
let rgbaImage2 = RGBAImage(image: image)!
let newImage4 = FilteredImage(image: rgbaImage2).Filter("contrast", value: 30).Filter("brightness", value: 100).Filter("color", filtercolor: "green").image.toUIImage()!




//Comment out the following line to let Playground run, and uncomment it while editing code to not always refresh
//*/