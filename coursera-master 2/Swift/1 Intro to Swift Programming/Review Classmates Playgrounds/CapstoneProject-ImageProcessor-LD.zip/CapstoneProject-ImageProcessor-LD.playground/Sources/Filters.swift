import Foundation

// 1.					CALCULATING GLOBAL IMAGE PROPERTIES

		//Average Red

public func AverageRed (rgbaImage:RGBAImage)->(Int){
	
	var TotalRed:Int=0
	for i in 0..<rgbaImage.height{
		for j in 0..<rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			TotalRed+=Int(pixel.red)
		}
	}
	let averageRed=(TotalRed/(rgbaImage.width*rgbaImage.height))
	return averageRed
}

		//Average Green

public func AverageGreen (rgbaImage:RGBAImage)->(Int){

	var TotalGreen:Int=0
	for i in 0..<rgbaImage.height{
		for j in 0..<rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			TotalGreen+=Int(pixel.green)
		}
	}
	let averageGreen=(TotalGreen/(rgbaImage.width*rgbaImage.height))
	return averageGreen
}

		//Average Blue

public func AverageBlue (rgbaImage:RGBAImage)->(Int){
	
	var TotalBlue:Int=0
	for i in 0..<rgbaImage.height{
		for j in 0..<rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			TotalBlue+=Int(pixel.blue)
		}
	}
	let averageBlue=(TotalBlue/(rgbaImage.width*rgbaImage.height))
	return averageBlue
}

public func AverageTransparency (rgbaImage:RGBAImage)->(Int){
	
	var TotalTransparency:Int=0
	for i in 0..<rgbaImage.height{
		for j in 0..<rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			TotalTransparency+=Int(pixel.alpha)
		}
	}
	let averageTransparency=(TotalTransparency/(rgbaImage.width*rgbaImage.height))
	return averageTransparency
}


		//Brightness

public func Brightness (rgbaImage:RGBAImage)->(Int){
	
	let brightness=(AverageRed(rgbaImage)+AverageGreen(rgbaImage)+AverageBlue(rgbaImage))/3

	return brightness
}



// 2.						ADDING SOME COLORS

		//Reddening

public func Reddening (rgbaImage:RGBAImage,RedFactor:Int)->RGBAImage{
	var NewrgbaImage:RGBAImage=rgbaImage
	let averageRed=UInt8(AverageRed(NewrgbaImage))
	for i in 0...NewrgbaImage.height-2{
		for j in 0...NewrgbaImage.width{
			let index:Int=i*NewrgbaImage.width+j
			var pixel=NewrgbaImage.pixels[index]
			var DeltaRed=Int(pixel.red)-Int(averageRed)
			if DeltaRed>0{
				if Int(pixel.red)+DeltaRed*RedFactor>255{
					pixel.red=255
				}
				else{
					pixel.red=min(pixel.red+UInt8(DeltaRed*RedFactor),255)}
			}
			NewrgbaImage.pixels[index]=pixel
		}
	}
	return NewrgbaImage
}

public func DefaultReddening (rgbaImage:RGBAImage)->RGBAImage{
	let NewRgbaImage=Reddening(rgbaImage,RedFactor:5)
	return NewRgbaImage
}
		//Greening

public func Greening (rgbaImage:RGBAImage,GreenFactor:Int)->RGBAImage{
	let averageGreen=UInt8(AverageGreen(rgbaImage))
	for i in 0...rgbaImage.height-2{
		for j in 0...rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			var DeltaGreen=Int(pixel.green)-Int(averageGreen)
			if DeltaGreen>0{
				if Int(pixel.green)+DeltaGreen*GreenFactor>255{
					pixel.green=255
				}
				else{
					pixel.green=min(pixel.green+UInt8(DeltaGreen*GreenFactor),255)}
			}
			rgbaImage.pixels[index]=pixel
		}
	}
	return rgbaImage
}

public func DefaultGreening (rgbaImage:RGBAImage)->RGBAImage{
	let NewRgbaImage=Greening(rgbaImage,GreenFactor:5)
	return NewRgbaImage
}

		//Blueing

public func Blueing (rgbaImage:RGBAImage,BlueFactor:Int)->RGBAImage{
	let averageBlue=UInt8(AverageBlue(rgbaImage))
	for i in 0...rgbaImage.height-2{
		for j in 0...rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			var DeltaBlue=Int(pixel.blue)-Int(averageBlue)
			if DeltaBlue>0{
				if Int(pixel.blue)+DeltaBlue*BlueFactor>255{
					pixel.blue=255
				}
				else{
					pixel.blue=min(pixel.blue+UInt8(DeltaBlue*BlueFactor),255)}
			}
			rgbaImage.pixels[index]=pixel
		}
	}
	return rgbaImage
}

public func DefaultBlueing (rgbaImage:RGBAImage)->RGBAImage{
	let NewRgbaImage=Blueing(rgbaImage,BlueFactor:5)
	return NewRgbaImage
}

// 3.						PLAYING ON CONTRAST


		//GreenContrasting

public func GreenContrasting (rgbaImage:RGBAImage,GreenFactor:Int)->RGBAImage{
	let averageGreen=UInt8(AverageGreen(rgbaImage))
	for i in 0...rgbaImage.height-2{
		for j in 0...rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			var DeltaGreen=Int(pixel.green)-Int(averageGreen)
			if (Int(pixel.green)+DeltaGreen*GreenFactor>255){
				pixel.green=255
			}
			else {
				if	(Int(pixel.green)+DeltaGreen*GreenFactor<0){
					pixel.green=0
				}
				else{
					pixel.green=UInt8(max(min(Int(pixel.green)+DeltaGreen*GreenFactor,255),0))}
			}
			rgbaImage.pixels[index]=pixel
		}
	}
	return rgbaImage
}

public func DefaultGreenContrasting (rgbaImage:RGBAImage)->RGBAImage{
	let NewRgbaImage=GreenContrasting(rgbaImage,GreenFactor:5)
	return NewRgbaImage
}
		//RedContrasting

public func RedContrasting (rgbaImage:RGBAImage,RedFactor:Int)->RGBAImage{
	let averageRed=UInt8(AverageRed(rgbaImage))
	for i in 0...rgbaImage.height-2{
		for j in 0...rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			var DeltaRed=Int(pixel.red)-Int(averageRed)
			if (Int(pixel.red)+DeltaRed*RedFactor>255){
				pixel.red=255
			}
			else {
				if	(Int(pixel.red)+DeltaRed*RedFactor<0){
					pixel.red=0
				}
				else{
					pixel.red=UInt8(max(min(Int(pixel.red)+DeltaRed*RedFactor,255),0))}
			}
			rgbaImage.pixels[index]=pixel
		}
	}
	return rgbaImage
}

public func DefaultRedContrasting (rgbaImage:RGBAImage)->RGBAImage{
	let NewRgbaImage=RedContrasting(rgbaImage,RedFactor:5)
	return NewRgbaImage
}

		//BlueContrasting

public func BlueContrasting (rgbaImage:RGBAImage,BlueFactor:Int)->RGBAImage{
	let averageBlue=UInt8(AverageBlue(rgbaImage))
	for i in 0...rgbaImage.height-2{
		for j in 0...rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			var DeltaBlue=Int(pixel.blue)-Int(averageBlue)
			if (Int(pixel.blue)+DeltaBlue*BlueFactor>255){
				pixel.blue=255
			}
			else {
				if	(Int(pixel.blue)+DeltaBlue*BlueFactor<0){
					pixel.blue=0
				}
				else{
					pixel.blue=UInt8(max(min(Int(pixel.green)+DeltaBlue*BlueFactor,255),0))}
			}
			rgbaImage.pixels[index]=pixel
		}
	}
	return rgbaImage
}

public func DefaultBlueContrasting (rgbaImage:RGBAImage)->RGBAImage{
	let NewRgbaImage=BlueContrasting(rgbaImage,BlueFactor:5)
	return NewRgbaImage
}
		// Contrasting

public func Contrasting (rgbaImage:RGBAImage,ContrastFactor:Int)->RGBAImage{
	var NewRgbaImage=rgbaImage
	RedContrasting(rgbaImage, RedFactor: ContrastFactor)
	GreenContrasting(rgbaImage, GreenFactor: ContrastFactor)
	BlueContrasting(rgbaImage, BlueFactor: ContrastFactor)
	return NewRgbaImage
}

public func DefaultContrasting (rgbaImage:RGBAImage)->RGBAImage{
	let NewRgbaImage=Contrasting(rgbaImage,ContrastFactor:10)
	return NewRgbaImage
}

// 4.						MORE FUN

public func Warhol (rgbaImage:RGBAImage,ContrastFactor:Int)->RGBAImage{
	var NewrgbaImage:RGBAImage=Contrasting(rgbaImage,ContrastFactor: ContrastFactor)
	for i in 0...NewrgbaImage.height-2{
		for j in 0...NewrgbaImage.width{
			let index:Int=i*NewrgbaImage.width+j
			var pixel=NewrgbaImage.pixels[index]
			if Int(pixel.red)<AverageRed(rgbaImage) && Int(pixel.green) < AverageGreen(rgbaImage) && Int(pixel.blue) < AverageBlue(rgbaImage) {
				pixel.red=0
				pixel.green=0
				pixel.blue=255
			}
			else {
				if Int(pixel.red)>AverageRed(rgbaImage) && Int(pixel.green) > AverageGreen(rgbaImage) && Int(pixel.blue) > AverageBlue(rgbaImage) {
					pixel.red=0
					pixel.green=255
					pixel.blue=0
				}
				else {
					pixel.red=255
					pixel.green=0
					pixel.blue=0
				}
			}
			NewrgbaImage.pixels[index]=pixel
		}
	}
	return NewrgbaImage
}

// Negative

public func Negative (rgbaImage:RGBAImage,ContrastFactor:Int)->RGBAImage{
	let NewRgbaImage=Contrasting(rgbaImage,ContrastFactor:-ContrastFactor)
	return NewRgbaImage
}

// RedSpot

public func RedSpot (rgbaImage:RGBAImage,Diameter:Double)->RGBAImage{
	let Ycenter=rgbaImage.height/2
	let Xcenter=rgbaImage.width/2
	let Diag:Double=sqrt(pow(Double(Xcenter),2)+pow(Double(Ycenter),2))
	for i in 0...rgbaImage.height-2{
		for j in 0...rgbaImage.width{
			let index:Int=i*rgbaImage.width+j
			var pixel=rgbaImage.pixels[index]
			let X2:Double=pow(Double(Xcenter-j+1),2)
			let Y2:Double=pow(Double(Ycenter-i+1),2)
			let distance:Double=sqrt(X2+Y2)*2
			let slope=Double(distance/Diag)
			if slope<Diameter {
				pixel.red=(1-2*UInt8(slope))*255
			}
			else {
				pixel.red=0
			}
			rgbaImage.pixels[index]=pixel
		}
	}
	return rgbaImage
}

// DefaultWarhol

public func DefaultWarhol (rgbaImage:RGBAImage)->(RGBAImage){
	let NewRgbaImage=Warhol(rgbaImage, ContrastFactor:3)
	return NewRgbaImage
}

// DefaultNegative

public func DefaultNegative (rgbaImage:RGBAImage)->RGBAImage{
	let NewRgbaImage=Contrasting(rgbaImage,ContrastFactor:-3)
	return NewRgbaImage
}