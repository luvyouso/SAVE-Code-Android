//: Playground - noun: a place where people can play

import UIKit

let image = UIImage(named: "sample")

//Here are the functions that can be used

//public func Reddening (rgbaImage:RGBAImage,RedFactor:Int)->RGBAImage{
//public func RedContrasting (rgbaImage:RGBAImage,RedFactor:Int)->RGBAImage{

//public func Greening (rgbaImage:RGBAImage,GreenFactor:Int)->RGBAImage{
//public func GreenContrasting (rgbaImage:RGBAImage,GreenFactor:Int)->RGBAImage{

//public func Blueing (rgbaImage:RGBAImage,BlueFactor:Int)->RGBAImage{
//public func BlueContrasting (rgbaImage:RGBAImage,BlueFactor:Int)->RGBAImage{

//public func Contrasting (rgbaImage:RGBAImage,ContrastFactor:Int)->RGBAImage{
//public func Warhol (rgbaImage:RGBAImage,ContrastFactor:Int)->RGBAImage{
//public func Negative (rgbaImage:RGBAImage,ContrastFactor:Int)->RGBAImage{
//public func RedSpot (rgbaImage:RGBAImage,Diameter:Double)->RGBAImage{ (diameter between 0 and 1)

// To use the filters in a default way, just put Default at the beginning of the function name, for example DefaultWarhol instead of Warhol.


// Process the image!
let sample = RGBAImage(image:image!)!

let image1=DefaultReddening(sample).toUIImage()!
let image2=Contrasting(sample, ContrastFactor: 10).toUIImage()!
let image3=Negative(sample,ContrastFactor:3).toUIImage()!
let image3bis=Negative(sample,ContrastFactor:6).toUIImage()!
let image4=DefaultWarhol(sample).toUIImage()!
let image5=RedSpot(sample, Diameter: 1).toUIImage()!
let image6=RedContrasting(sample,RedFactor:-15).toUIImage()!


