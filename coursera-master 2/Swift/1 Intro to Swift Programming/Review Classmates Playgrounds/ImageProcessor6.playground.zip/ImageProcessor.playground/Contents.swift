//: Playground - noun: a place where people can play

import UIKit


let image = UIImage(named: "sample.png")!

// Process the image!
let cImage = RGBAImage(image: image)!;

var imageProcessor = ImageProcessor(image: cImage)

// first add some defaults
imageProcessor?.applyDefault("Hot")
imageProcessor?.applyDefault("2xContrast")

// now some custom ones
imageProcessor?.applyFilter("Warmer", intensity: 1)
imageProcessor?.applyFilter("Brightness", intensity: -50)
imageProcessor?.applyFilter("Contrast", intensity: 1.5)
imageProcessor?.applyFilter("Brightness", intensity: 10)
imageProcessor?.applyFilter("Cooler", intensity: 3)


let processedImage = cImage.toUIImage();




