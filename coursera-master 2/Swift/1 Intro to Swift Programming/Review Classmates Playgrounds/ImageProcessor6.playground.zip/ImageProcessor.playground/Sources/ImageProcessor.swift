import Foundation

public struct ImageProcessor {
    public var rgbaImage: RGBAImage
    
    //private var filters: [String:(pixel: Pixel) -> (Pixel)]
    private var filters: [String:(intensity: Double) -> (pixel: Pixel) -> (Pixel)]
    private var defaultFilters: [String:(pixel: Pixel) -> (Pixel)]
    
    public init?(image: RGBAImage) {
        rgbaImage = image
        filters = [:]
        defaultFilters = [:]
        
        // now add the available filters
        filters["Warmer"] = { (intensity) -> (pixel: Pixel) -> (Pixel) in
            
            let factor = 1.0 + (intensity / 100.0)
            
            return { (pixel) -> (Pixel) in
            
                let r = round(Double(pixel.red) * factor)
                var newPixel = pixel
            
                newPixel.red = UInt8(max(min(r, 255), 0))
            
                return newPixel
            }

        }
        
        filters["Cooler"] = { (intensity) -> (pixel: Pixel) -> (Pixel) in
            
            let factor = 1.0 + (intensity / 100.0)
            
            return { (pixel) -> (Pixel) in
                
                let b = round(Double(pixel.blue) * factor)
                var newPixel = pixel
                
                newPixel.blue = UInt8(max(min(b, 255), 0))
                
                return newPixel
            }
            
        }
        
        
        filters["Contrast"] = { (intensity) -> (pixel: Pixel) -> (Pixel) in
            
            
            return { (pixel) -> (Pixel) in
            
                var totalRed = 0
                var totalGreen = 0
                var totalBlue = 0
            
                let factor = Int(round(intensity))
                
                for i in 0..<self.rgbaImage.pixels.count {
                    totalRed += Int(self.rgbaImage.pixels[i].red)
                    totalGreen += Int(self.rgbaImage.pixels[i].green)
                    totalBlue += Int(self.rgbaImage.pixels[i].blue)
                }
            
                let avgRed = totalRed / self.rgbaImage.pixels.count
                let avgGreen = totalGreen / self.rgbaImage.pixels.count
                let avgBlue = totalBlue / self.rgbaImage.pixels.count
            
                let redDelta = Int(pixel.red) - avgRed
                let greenDelta = Int(pixel.green) - avgGreen
                let blueDelta = Int(pixel.blue) - avgBlue
            
                var newPixel = pixel
            
                newPixel.red = UInt8(max(min(avgRed + factor * redDelta, 255), 0))
                newPixel.green = UInt8(max(min(avgGreen + factor * greenDelta, 255), 0))
                newPixel.blue = UInt8(max(min(avgBlue + factor * blueDelta, 255), 0))
            
                return newPixel
            }
            
        }
        
        filters["Brightness"] = { (intensity) -> (pixel: Pixel) -> (Pixel) in
            
            return { (pixel)  -> (Pixel) in
            
                let factor = 1.0 + (intensity / 100.0)
                
                let r = round(Double(pixel.red) * factor)
                let b = round(Double(pixel.blue) * factor)
                let g = round(Double(pixel.green) * factor)
            
                var newPixel = pixel
            
                newPixel.red = UInt8(max(min(r, 255), 0))
                newPixel.blue = UInt8(max(min(b, 255), 0))
                newPixel.green = UInt8(max(min(g, 255), 0))
            
                return newPixel
            }
        }
        
        
        // using the avilable filters create some defaults
        defaultFilters["Hot"] = (filters["Warmer"]!(intensity: 50))
        defaultFilters["Cold"] = (filters["Cooler"]!(intensity: 50))
        defaultFilters["2xContrast"] = (filters["Contrast"]!(intensity: 2))
        defaultFilters["50Brighness"] = (filters["Brightness"]!(intensity: 50))
        
    }
    
    public func applyFilter(filterName: String, intensity: Double) {
        let f = filters[filterName];
        
        rgbaImage.filter(f!(intensity: intensity))
    }
    
    public func applyDefault(filterName: String) {
        rgbaImage.filter(defaultFilters[filterName]!)
    }
    
}

