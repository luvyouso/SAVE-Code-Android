//: Playground - noun: a place where people can play

import UIKit

let image = UIImage(named: "sample")!





// Process the image!

let rgbaImage = RGBAImage(image: image)!

var myImageProcessor = ImageProcessor(rgbaImage: rgbaImage)!

//-----------------------------
// Apply 5 Default Filter
// "Brightness 2x"
// "Brightness 5x"
// "Contrast 4x"
// "Contrast 8x"
// "GrayScale"
//-----------------------------
let defaultFilterImage = myImageProcessor.ApplyDefaultFilter("GrayScale 3x").toUIImage()!



//-----------------------------------
// Apply Custom Filter
// e.g. "Brightness:2"
// Brightness value can be -10 to 10
// e.g. "Contrast:2"
// Contrast can be 0 to 10
// e.g GrayScale:5
// GrayScale values can be -10 to 10
//-----------------------------------

let customFilterImage = myImageProcessor.ApplyCustomFilter("Brightness:4").toUIImage()!

//-----------------------------------
// Apply array of random Filter
//-----------------------------------

let filterArr = ["Brightness:-3", "Contrast:2"]

let arrayCustomImage = myImageProcessor.ApplyFilterArray(filterArr).toUIImage()!











