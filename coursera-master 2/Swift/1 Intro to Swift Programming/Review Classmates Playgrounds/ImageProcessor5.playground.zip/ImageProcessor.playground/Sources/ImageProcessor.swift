

public struct ImageProcessor {
    var mImage: RGBAImage
    public var avgRed: Int
    public var avgBlue: Int
    public var avgGreen: Int
    public var pixelCount: Int
    
    
    public init?(rgbaImage: RGBAImage) {
        
        mImage = rgbaImage
        
        var totalRed = 0
        var totalGreen = 0
        var totalBlue = 0
        
        for y in 0..<mImage.height {
            for x in 0..<mImage.width {
                let index = y * mImage.width + x
                let pixel = mImage.pixels[index]
                
                totalRed += Int(pixel.red)
                totalGreen += Int(pixel.green)
                totalBlue += Int(pixel.blue)
            }
        }
        
        pixelCount = mImage.width * mImage.height
        
        avgRed = totalRed / pixelCount
        avgGreen = totalGreen / pixelCount
        avgBlue = totalBlue / pixelCount
        
    }
    
    
    public func IncreaseBrightness( brightnessfactor: Int) -> RGBAImage {
        let tempImage = RGBAImage(image: mImage.toUIImage()!)!
        let brightnessValue = 255 * brightnessfactor / 10
        
        for y in 0..<mImage.height {
            for x in 0..<mImage.width {
                let index = y * mImage.width + x
                var pixel = mImage.pixels[index]
                
                let brighterRed = min(255, Int(pixel.red) + brightnessValue)
                let brighterGreen = min(255, Int(pixel.green) + brightnessValue)
                let brighterBlue = min(255, Int(pixel.blue) + brightnessValue)
                //
                pixel.red = UInt8(brighterRed)
                pixel.green = UInt8(brighterGreen)
                pixel.blue = UInt8(brighterBlue)
                
                tempImage.pixels[index] = pixel
            }
        }
        
        return tempImage
        
    }
    
    
    
    public func DecreaseBrightness( brightnessfactor: Int) -> RGBAImage {
        let tempImage = RGBAImage(image: mImage.toUIImage()!)!
        let brightnessValue = 255 * brightnessfactor / 10
        //let brightnessValue = 50
        
        for y in 0..<mImage.height {
            for x in 0..<mImage.width {
                let index = y * mImage.width + x
                var pixel = mImage.pixels[index]
                
                let brighterRed = max(0, Int(pixel.red) - brightnessValue)
                let brighterGreen = max(0, Int(pixel.green) - brightnessValue)
                let brighterBlue = max(0, Int(pixel.blue) - brightnessValue)
                //
                pixel.red = UInt8(brighterRed)
                pixel.green = UInt8(brighterGreen)
                pixel.blue = UInt8(brighterBlue)
                
                tempImage.pixels[index] = pixel
            }
        }
        
        return tempImage
        
    }
    
    public func ConvertToGrayScale( grayScalefactor: Int) -> RGBAImage {
        let tempImage = RGBAImage(image: mImage.toUIImage()!)!
        let grayScaleFactorValue = 255 * grayScalefactor / 10
        
        for y in 0..<tempImage.height {
            for x in 0..<tempImage.width {
                let index = y * tempImage.width + x
                var pixel = tempImage.pixels[index]
                
                var grayScaleValue = (Int(pixel.red) + Int(pixel.green) + Int(pixel.blue)) / 3
                
                grayScaleValue =  max(0, min(255, grayScaleValue + grayScaleFactorValue))
                //
                pixel.red = UInt8(grayScaleValue)
                pixel.green = UInt8(grayScaleValue)
                pixel.blue = UInt8(grayScaleValue)
                
                tempImage.pixels[index] = pixel
            }
        }
        
        return tempImage
    }
    
    public func AdjustContrast( contrastFactor: Int) -> RGBAImage {
        
        let tempImage = RGBAImage(image: mImage.toUIImage()!)!
        
        for y in 0..<mImage.height {
            for x in 0..<mImage.width {
                let index = y * mImage.width + x
                var pixel = mImage.pixels[index]
                
                var newRed = ((Int(pixel.red) - avgRed) * contrastFactor) + avgRed
                newRed = max(0, min(255, newRed))
                
                var newBlue = ((Int(pixel.blue) - avgBlue) * contrastFactor) + avgBlue
                newBlue = max(0, min(255, newBlue))
                
                var newGreen = ((Int(pixel.green) - avgGreen) * contrastFactor) + avgGreen
                newGreen = max(0, min(255, newGreen))
                
                pixel.red = UInt8(newRed)
                pixel.green = UInt8(newBlue)
                pixel.blue = UInt8(newGreen)
                
                tempImage.pixels[index] = pixel
            }
        }
        
        return tempImage
    }
    
    public func SetSepiaTone() -> RGBAImage {
        
        let tempImage = RGBAImage(image: mImage.toUIImage()!)!
        
        for y in 0..<mImage.height {
            for x in 0..<mImage.width {
                let index = y * mImage.width + x
                var pixel = mImage.pixels[index]
                
                let outputRed = min(255, (Double(pixel.red) * 0.393) + (Double(pixel.green) * 0.769) + (Double(pixel.blue) * 0.189))
                let outputGreen = min(255, (Double(pixel.red) * 0.349) + (Double(pixel.green) * 0.686) + (Double(pixel.blue) * 0.168))
                
                let outputBlue = min(255, (Double(pixel.red) * 0.272) + (Double(pixel.green) * 0.534) + (Double(pixel.blue) * 0.131))
                //
                pixel.red = UInt8(outputRed)
                pixel.green = UInt8(outputGreen)
                pixel.blue = UInt8(outputBlue)
                
                tempImage.pixels[index] = pixel
            }
        }
        
        return tempImage
    }
    
    
    public mutating func ApplyCustomFilter(filterString: String) -> RGBAImage {
        var processedImage:RGBAImage = mImage
        let splitArray = filterString.componentsSeparatedByString(":")
        let filterType = splitArray[0]
        let filterParam = splitArray[1]
        
        switch filterType {
            case "Brightness":
                if Int(filterParam)! > 0 {
                    processedImage = IncreaseBrightness(Int(filterParam)!)
                }
                else {
                    processedImage = DecreaseBrightness(-1*Int(filterParam)!)
                }
        case "Contrast":
                processedImage = AdjustContrast(Int(filterParam)!)
        case "GrayScale":
                processedImage = ConvertToGrayScale(Int(filterParam)!)
            
        default:
            return IncreaseBrightness(2)
        }
        
        return processedImage
    }
    
    public func ApplyDefaultFilter(filterString: String) -> RGBAImage {
        
        switch filterString {
        case "Brightness 2x":
            return IncreaseBrightness(2)
        case "Brightness 5x":
            return IncreaseBrightness(5)
        case "Contrast 4x":
            return AdjustContrast(4)
        case "Contrast 8x":
            return AdjustContrast(8)
        case "GrayScale 3x":
            return ConvertToGrayScale(3)
        default:
            return IncreaseBrightness(2)
        }
        
    }
    
    public mutating func ApplyFilterArray(filterArray: [String]) -> RGBAImage {
        var processedImage:RGBAImage = mImage
        for i in 0..<filterArray.count {
            let element = filterArray[i]
            
            let splitArray = element.componentsSeparatedByString(":")
            let filterType = splitArray[0]
            let filterParam = splitArray[1]
            switch filterType {
            case "Brightness":
                if Int(filterParam) > 0 {
                    processedImage = IncreaseBrightness(Int(filterParam)!)
                }
                else {
                    processedImage = DecreaseBrightness(-1*Int(filterParam)!)
                }
            case "Contrast":
                processedImage = AdjustContrast(Int(filterParam)!)
            case "GrayScale":
                processedImage = ConvertToGrayScale(Int(filterParam)!)
            default:
                break
            }
            
        }
        
        return processedImage
    }
    
}