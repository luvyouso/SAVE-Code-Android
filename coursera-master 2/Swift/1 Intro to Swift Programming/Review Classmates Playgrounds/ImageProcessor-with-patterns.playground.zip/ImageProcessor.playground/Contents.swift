//: Playground - noun: a place where people can play

import UIKit

let image = UIImage(named: "sample")!
var rgbaImage = RGBAImage(image: image)!
var outputImage: UIImage

var filterFactory: FilterFactory = FilterFactory(image: rgbaImage)

//let filterCommands: [FilterCommand] = [
//    FilterCommand(filter: Filters.Brightness, seed: 5),
//    FilterCommand(filter: Filters.Contrast, seed: 30)
//]

//filterFactory.applyFilters(filterCommands)

filterFactory.applyFilter(FilterCommand(filter: Filters.Brightness, seed: 5))

outputImage = filterFactory.getImage()

filterFactory.applyFilter(FilterCommand(filter: Filters.Contrast, seed: 5))

outputImage = filterFactory.getImage()
