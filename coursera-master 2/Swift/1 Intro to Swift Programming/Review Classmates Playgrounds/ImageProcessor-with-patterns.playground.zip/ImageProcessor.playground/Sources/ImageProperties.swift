import Foundation


public class ImageProperties {
    var pixelCount: Int = 0
    
    var _red: Int = 0
    var _green: Int = 0
    var _blue: Int = 0
    
    public var totalRed: Int {
        get {
            return _red
        }
    }
    
    public var totalGreen: Int {
        get {
            return _green
        }
    }
    
    public var totalBlue: Int {
        get {
            return _blue
        }
    }
    
    public var avgRed: Int {
        get {
            return _red / pixelCount
        }
    }
    
    public var avgGreen: Int {
        get {
            return _green / pixelCount
        }
    }
    
    public var avgBlue: Int {
        get {
            return _blue / pixelCount
        }
    }
    
    var sumColors: Int {
        get {
            return _red + _green + _blue
        }
    }
    
    init(rgbaImage: RGBAImage) {
        pixelCount = rgbaImage.width * rgbaImage.height
        
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                let index = y * rgbaImage.width + x
                let pixel = rgbaImage.pixels[index]
                
                _red += Int(pixel.red)
                _blue += Int(pixel.blue)
                _green += Int(pixel.green)
            }
        }
    }
}