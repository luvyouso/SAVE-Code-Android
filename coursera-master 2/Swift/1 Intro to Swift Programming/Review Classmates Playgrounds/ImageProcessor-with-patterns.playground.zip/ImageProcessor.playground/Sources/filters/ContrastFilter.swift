import Foundation


public class ContrastFilter: Filterable {
    public func apply(image: RGBAImage, command: FilterCommand) -> RGBAImage {
        let properties: ImageProperties = ImageProperties(rgbaImage: image)
        
        for y in 0..<image.height {
            for x in 0..<image.width {
                let index = y * image.width + x
                var pixel = image.pixels[index]
                
                let redDelta = Int(pixel.red) - properties.avgRed
                let blueDelta = Int(pixel.blue) - properties.avgBlue
                let greenDelta = Int(pixel.green) - properties.avgGreen
                
                pixel.red = UInt8(max(min(255, properties.avgRed - command.seed * redDelta), 0))
                pixel.blue = UInt8(max(min(255, properties.avgBlue - command.seed * blueDelta), 0))
                pixel.green = UInt8(max(min(255, properties.avgGreen - command.seed * greenDelta), 0))
                image.pixels[index] = pixel
            }
        }
        
        return image
    }
}