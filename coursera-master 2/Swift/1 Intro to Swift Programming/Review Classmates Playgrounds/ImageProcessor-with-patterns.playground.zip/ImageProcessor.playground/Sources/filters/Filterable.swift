import UIKit
import Foundation


public protocol Filterable {
    func apply(image: RGBAImage, command: FilterCommand) -> RGBAImage
}