import UIKit
import Foundation


public class FilterFactory {
    var image: RGBAImage
    
    public init(image: RGBAImage) {
        self.image = image
    }
    
    public func applyFilter(command: FilterCommand) {
        var filter: Filterable
        
        switch (command.filter) {
        case Filters.Brightness:
            filter = BrightFilter()
        case Filters.Contrast:
            filter = ContrastFilter()
        }
        
        image = filter.apply(image, command: command)
    }
    
    public func applyFilters(commands: [FilterCommand]) {
        for command in commands {
            applyFilter(command)
        }
    }
    
    public func getImage() -> UIImage {
        return image.toUIImage()!
    }
}