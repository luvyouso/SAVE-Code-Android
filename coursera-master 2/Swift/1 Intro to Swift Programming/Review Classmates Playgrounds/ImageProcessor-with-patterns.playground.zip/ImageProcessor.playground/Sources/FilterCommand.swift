import Foundation


public class FilterCommand {
    var filter: Filters
    var seed: Int
    
    public init (filter: Filters, seed: Int) {
        self.filter = filter
        self.seed = seed
    }
}