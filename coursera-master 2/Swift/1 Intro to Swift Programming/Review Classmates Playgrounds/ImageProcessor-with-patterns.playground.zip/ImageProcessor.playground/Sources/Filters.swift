import Foundation


public enum Filters {
    case Contrast
    case Brightness
}