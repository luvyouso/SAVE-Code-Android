/* 
    Hi! Please scroll all the way to the bottom to see the tests for the various filters
    I implemented the filters through subclassing - there is a super class ImageFilter that provides some utility methods
    The actual filters simply provide implementation of the transformation and default settings
    I would have liked a functional solution better but there course hasn't really touched much on the functional aspects of Swift...so maybe later :-)

    Settings - I decided to use Pixel for settings - because many of the filters apply different ratio or adjustment to each of the channels and Pixel already provides values for all the channels. To make it work I had to add init method to the Pixel struct

    Where reasonable, I provided an interface to translate settings in a string form to the actual settings in Pixel
*/

import UIKit

let image = UIImage(named: "sample.png")

// Process the image!
let rgbaImage = RGBAImage(image: image!)!


//ImageProcessor class - a wrapper for the filters
//the filters are provided as a dictionary so that it can be extended with more filters at runtime
class ImageProcessor {
    let image:RGBAImage
    let filters:[String:ImageFilter] = [
        "Invert": ImageFilterInvert(),
        "Sepia": ImageFilterSepia(),
        "AddAlpha": ImageFilterAddAlpha(),
        "GrayScale": ImageFilterGrayScale(),
        "Colorize": ImageFilterColorize()
    ]
    
    init(imageName:String){
        self.image = RGBAImage(image: UIImage(named:imageName)!)!
    }
    
    init(image:RGBAImage){
        self.image = image
    }
    
   //this method does the actual job - calls apply on filter and returns a new instance
    //of ImageProcessor to provide a fluid interface - you can just call the result with .apply(another_filter)
    func apply(filter:String, settings: Pixel?) -> ImageProcessor {
        let filter = filters[filter]
        
        if filter != nil {
            return ImageProcessor(image: filter!.apply(self.image, settings: settings == nil ? filter!.defaultSettings() : settings!))
        } else {
            return self
        }
    }
    
    func toUIImage() -> UIImage {
        return self.image.toUIImage()!
    }
}

//kind of a stab at polymorphism - each filter has to have some default settings and the function that will transform the pixel (i.e. apply the filter to the pixel)
protocol ImageFilterProtocol {
    func defaultSettings() -> Pixel

    func filterPixel(pixel: Pixel, settings: Pixel) -> Pixel
}

//super class for the filters provides the loop over pixels so that the actual filters
//only need to worry about the transformation function and default settings
class ImageFilter: ImageFilterProtocol {
    //defaultly use the linar process where pixels are transformed in isolation one by one
    //but it could be overriden to use a different process where squares of e.g. 10x10 are processed
    func apply(image: RGBAImage, settings: Pixel) -> RGBAImage {
        return linearProcess(image, settings: settings)
    }
    
    func linearProcess(image: RGBAImage, settings: Pixel) -> RGBAImage {
        for y in 0..<image.height {
            for x in 0..<image.width {
                let index = y * image.width + x
                
                image.pixels[index] = filterPixel(image.pixels[index], settings: settings)
            }
        }
        
        return image
    }
    
    func filterPixel(let pixel: Pixel, settings: Pixel) -> Pixel {
        preconditionFailure("This method must be overridden")
    }
    
    func defaultSettings() -> Pixel {
        preconditionFailure("This method must be overridden")
    }
}


//implementation of the invert filter
class ImageFilterInvert: ImageFilter {
    let fullColor = UInt8(255)
    
    //for default settings 255 - channel will always be >= 0 but if it does go to negative value for some settings just set the channel to 0 (I could maybe do absolute value...)
    override func filterPixel(var pixel: Pixel, settings: Pixel) -> Pixel {
        pixel.red = max(0, settings.red - pixel.red)
        pixel.green = max(0, settings.green - pixel.green)
        pixel.blue = max(0, settings.blue - pixel.blue)
        
        return pixel;
    }
    
    //the default settings provide `full color` i.e. all channels except for alpha set to 255
    //this is to conform to the assignment - you can provide different default settings which will allow to invert some chanels more than others
    override func defaultSettings() -> Pixel {
        return Pixel(value: 0x00FFFFFF)
    }
}

//implementation of the Sepia filter
class ImageFilterSepia: ImageFilter {
    override func filterPixel(var pixel: Pixel, settings:Pixel) -> Pixel {
        let inputRed = Double(pixel.red)
        let inputGreen = Double(pixel.green)
        let inputBlue = Double(pixel.blue)
        
        let red = min(255, (inputRed * 0.393) + (inputGreen * 0.769) + (inputBlue * 0.189))
        let green = min(255, (inputRed * 0.349) + (inputGreen * 0.686) + (inputBlue * 0.168))
        let blue = min(255, (inputRed * 0.272) + (inputGreen * 0.534) + (inputBlue * 0.131))
        
        pixel.red = UInt8(red)
        pixel.green = UInt8(green)
        pixel.blue = UInt8(blue)
        
        return pixel;
    }
    
    //there aren't any real settings here - it would actually require 3 pixels because
    //the transformation uses 9 different ratios
    override func defaultSettings() -> Pixel {
        return Pixel(value: 0x00000000)
    }
}

//implementation of the GrayScale filter
class ImageFilterGrayScale: ImageFilter {
    override func filterPixel(var pixel: Pixel, settings:Pixel) -> Pixel {
        let inputRed = pixel.red
        let inputGreen = pixel.green
        let inputBlue = pixel.blue
        
        let newRed = Double(settings.red) * Double(inputRed) / 255.0
        let newGreen = Double(settings.green) * Double(inputGreen) / 255.0
        let newBlue = Double(settings.blue) * Double(inputBlue) / 255.0
        
        let average = UInt8(max(0, min(255, newRed + newGreen + newBlue)))
        
        pixel.red = average
        pixel.green = average
        pixel.blue = average
        
        return pixel
    }
    
    //there are different formulas for averaging the colors when producing grayscale
    //e.g. Lightness, Average, Luminosity - you can google it
    override func defaultSettings() -> Pixel {
        return luminosity()
    }
    
    //this is to enable the configuration by string
    func settingsByName(name:String) -> Pixel {
        let settings = [
            "luminosity":luminosity(),
            "average":average()
        ]
        
        if (settings[name] != nil) {
            return settings[name]!
        } else {
            return defaultSettings()
        }
    }
    
    func luminosity() -> Pixel {
        var pix = Pixel(value: 0)
        pix.red = UInt8(0.21 * 255)
        pix.green = UInt8(0.72 * 255)
        pix.blue = UInt8(0.07 * 255)
        
        return pix
    }
    
    func average() -> Pixel {
        var pix = Pixel(value: 0)
        pix.red = UInt8(0.5 * 255)
        pix.green = UInt8(0.5 * 255)
        pix.blue = UInt8(0.5 * 255)
        
        return pix
    }

}

//Implementation of the Colorize filter
class ImageFilterColorize: ImageFilter {
    override func filterPixel(var pixel: Pixel, settings:Pixel) -> Pixel {
        let inputRed = Double(pixel.red)
        let inputGreen = Double(pixel.green)
        let inputBlue = Double(pixel.blue)
        
        let newRed = inputRed * 0.21
        let newGreen = inputGreen * 0.72
        let newBlue = inputBlue * 0.07
        
        let average = UInt8(max(0, min(255, newRed + newGreen + newBlue)))
        
        pixel.red = average <= settings.red ? average : 0
        pixel.green = average <= settings.green ? average : 0
        pixel.blue = average <= settings.blue ? average : 0
        
        return pixel
    }
    
    //there are different formulas for averaging the colors when producing grayscale
    //e.g. Lightness, Average, Luminosity - you can google it
    override func defaultSettings() -> Pixel {
        return redTint()
    }
    
    //this is to enable the configuration by string
    func settingsByName(name:String) -> Pixel {
        let settings = [
            "redTint":redTint(),
            "yellowTint":yellowTint()
        ]
        
        if (settings[name] != nil) {
            return settings[name]!
        } else {
            return defaultSettings()
        }
    }
    
    func redTint() -> Pixel {
        return Pixel(value: 0x000000FF)
    }
    
    func yellowTint() -> Pixel {
        return Pixel(value: 0x0000FFFF)
    }
    
}

//implementation of the filter to add alpha channel
class ImageFilterAddAlpha: ImageFilter {
    let fullColor = UInt8(255)
    
    override func filterPixel(var pixel: Pixel, settings: Pixel ) -> Pixel {
        pixel.alpha = settings.alpha
        
        return pixel;
    }
    
    //by default add 50% alpha
    override func defaultSettings() -> Pixel {
        return Pixel(value: 0x80000000)
    }
    
    //this is to enable the configuration by string
    func settingsByName(name:String) -> Pixel {
        let settings = [
            "10%":alpha(10),
            "25%":alpha(25),
            "50%": alpha(50),
            "75%": alpha(75),
            "100%": alpha(100)
        ]
        
        if (settings[name] != nil) {
            return settings[name]!
        } else {
            return defaultSettings()
        }
    }
    
    func alpha(value:Double) -> Pixel {
        var pix = Pixel(value: 0)
        pix.alpha = UInt8(max(0, min(255, value / 100.0 * 255.0)))
        
        return pix
    }


}


/* 
    You can test out the various filters here - just uncomment the `let newImage =` line
    DON'T UNCOMMENT TOO MANY AT ONE TIME - it may hang your XCode
*/

/* 1) invert the image - i.e. create a negative image of the original */
//let newImage = ImageProcessor(imageName: "sample.png").apply("Invert", settings: nil).toUIImage()

/* 2) sepia effect */
//let newImage2 = ImageProcessor(imageName: "sample.png").apply("Sepia", settings: nil).toUIImage()

/*  
    3) Add alpha layer - this will be useful for merging multiple images
    you can experiment by providing different levels of alpha e.g. Pixel(value: 0xCC000000) or Pixel(Value: 0x20000000) 
*/
//let newImage3 = ImageProcessor(imageName: "sample.png").apply("AddAlpha", settings: nil).toUIImage()


/* 
    4) convert to grayscale
        compare the following 2 images - both convert to grayscale but using a different settings
*/
//let newImage4 = ImageProcessor(imageName: "sample.png").apply("GrayScale", settings: nil).toUIImage()
//let newImage5 = ImageProcessor(imageName: "sample.png").apply("GrayScale", settings: ImageFilterGrayScale().average()).toUIImage()


/* 
    5) colorize
        The colorize filter adds a color lense effect - you can experiment with different color of the lense - make a combination of RGB and try it
*/
//let newImage6 = ImageProcessor(imageName: "sample.png").apply("Colorize", settings: ImageFilterColorize().yellowTint()).toUIImage()
//let newImage6 = ImageProcessor(imageName: "sample.png").apply("Colorize", settings: Pixel(value: UInt32(0x00FFFF00))).toUIImage()



/* 
    Lastly the image processor is designed as fluid interface so that you can chain the filters indefinetly. At the end just call toUIImage() to display the image
    It may take some time to calculate as there are 3 filters so the loop runs 3 x 56k times
*/
//let chain = ImageProcessor(imageName: "sample.png").apply("Invert", settings: nil).apply("Sepia", settings: nil).apply("AddAlpha", settings: nil).toUIImage()

