//
//  Filters.swift
//  Filterer
//
//  Created by Philippe Wanner on 13/11/15.
//  Copyright © 2015 UofT. All rights reserved.
//

import Foundation
import UIKit

class Filters{
    
    var numberFiltersApplied = 0
    
    init(){
        
    }
    
    func filterImage(img: UIImage, filterColor: String, idx: Float) -> UIImage{
        
        numberFiltersApplied++
        
        let rgbaImage: RGBAImage = RGBAImage(image: img)!
        
        switch(filterColor.lowercaseString){
            case "red":     self.filterImageRed(rgbaImage, modifierIdx: Double(idx))
            case "blue":    self.filterImageBlue(rgbaImage, modifierIdx: Double(idx))
            case "green":   self.filterImageGreen(rgbaImage, modifierIdx: Double(idx))
            case "yellow":  self.filterImageRed(rgbaImage, modifierIdx: Double(idx))
                            self.filterImageGreen(rgbaImage, modifierIdx: Double(idx))
            case "purple":  self.filterImageBlue(rgbaImage, modifierIdx: Double(idx))
                            self.filterImageGreen(rgbaImage, modifierIdx: Double(idx))
        default: print("did not find any filter")
        }
        
        return rgbaImage.toUIImage()!
    }
    
    func filterImageRed(img: RGBAImage, modifierIdx: Double){
        
        let avgColor = 107
        for y in 0..<img.height {
            for x in 0..<img.width {
                let index = y * img.width + x
                var pixel = img.pixels[index]
                let colorDelta = Int(pixel.red) - avgColor
                var modifier = modifierIdx+4 * (Double(y)/Double(img.height))
                
                if(Int(pixel.red)<avgColor){
                    modifier = modifierIdx
                }
                
                pixel.red = UInt8(max(min(255,Int(round(Double(avgColor) + modifier * Double(colorDelta)))),0))
                img.pixels[index] = pixel
            }
        }
    }
    
    func filterImageGreen(img: RGBAImage, modifierIdx: Double){
        
        let avgColor = 107
        for y in 0..<img.height {
            for x in 0..<img.width {
                let index = y * img.width + x
                var pixel = img.pixels[index]
                let colorDelta = Int(pixel.green) - avgColor
                var modifier = modifierIdx+4 * (Double(y)/Double(img.height))
                
                if(Int(pixel.green)<avgColor){
                    modifier = modifierIdx
                }
                
                pixel.green = UInt8(max(min(255,Int(round(Double(avgColor) + modifier * Double(colorDelta)))),0))
                img.pixels[index] = pixel
            }
        }
    }
    
    func filterImageBlue(img: RGBAImage, modifierIdx: Double){
        
        let avgColor = 107
        for y in 0..<img.height {
            for x in 0..<img.width {
                let index = y * img.width + x
                var pixel = img.pixels[index]
                let colorDelta = Int(pixel.blue) - avgColor
                var modifier = modifierIdx + 4 * (Double(y)/Double(img.height))
                
                if(Int(pixel.blue)<avgColor){
                    modifier = modifierIdx
                }
                
                pixel.blue = UInt8(max(min(255,Int(round(Double(avgColor) + modifier * Double(colorDelta)))),0))
                img.pixels[index] = pixel
            }
        }
    }
}
