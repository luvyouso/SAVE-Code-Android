//
//  ViewController.swift
//  Filterer
//
//  Created by Jack on 2015-09-22.
//  Copyright © 2015 UofT. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var originalImage: UIImage?
    var filteredImage: UIImage?
    
    @IBOutlet weak var redButton: UIImageView!
    @IBOutlet weak var greenButton: UIImageView!
    @IBOutlet weak var blueButton: UIImageView!
    @IBOutlet weak var yellowButton: UIImageView!
    @IBOutlet weak var purpleButton: UIImageView!
    
    let filters: Filters = Filters()
    
    var isShowingFiltered: Bool = true
    
    var currentFilter: String!
    
    @IBOutlet var firstImageView: UIImageView!
    
    @IBOutlet weak var secondImageView: UIImageView!
    
    @IBOutlet var secondaryMenu: UIView!
    
    @IBOutlet var editMenu: UIView!
    
    @IBOutlet var bottomMenu: UIView!
    
    @IBOutlet weak var intensitySlider: UISlider!
    
    @IBOutlet weak var intensityValue: UILabel!
    @IBOutlet var filterButton: UIButton!
    
    @IBOutlet weak var editButton: UIButton!
    
    @IBOutlet weak var compareButton: UIButton!
    
    @IBOutlet weak var originalOverlay: UILabel!
    
    var gestureRecognizer: UILongPressGestureRecognizer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Secondary Menu
        secondaryMenu.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0.5)
        secondaryMenu.translatesAutoresizingMaskIntoConstraints = false
        //Edit Menu
        editMenu.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0.5)
        editMenu.translatesAutoresizingMaskIntoConstraints = false
        
        filteredImage = firstImageView.image
        originalImage = firstImageView.image
        secondImageView.image = firstImageView.image
        secondImageView.alpha = 0
        compareButton.enabled = false
        editButton.enabled = false
        
        //Enable event on imageView
        firstImageView.userInteractionEnabled = true
        //instance the UITapGestureRecognizer and inform the method for the action "imageTapped"
        gestureRecognizer = UILongPressGestureRecognizer(target: self, action: "imageViewSingleTap")
        //set the image to the gesture
        firstImageView.addGestureRecognizer(gestureRecognizer)
        
        //Hide the original overlay
        hideOriginalOverlay()
        
        //Filter buttons
        updateImagesSndMenu(UIImage(named: "scenery")!)
        
        //Intensity label
        intensityValue.text = String(intensitySlider.value)
    }

    // MARK: Share
    @IBAction func onShare(sender: AnyObject) {
        let activityController = UIActivityViewController(activityItems: ["Check out our really cool app", firstImageView.image!], applicationActivities: nil)
        presentViewController(activityController, animated: true, completion: nil)
    }
    
    // MARK: New Photo
    @IBAction func onNewPhoto(sender: AnyObject) {
        let actionSheet = UIAlertController(title: "New Photo", message: nil, preferredStyle: .ActionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .Default, handler: { action in
            self.showCamera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Album", style: .Default, handler: { action in
            self.showAlbum()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .Cancel, handler: nil))
        
        self.presentViewController(actionSheet, animated: true, completion: nil)
    }
    
    func showCamera() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .Camera
        
        presentViewController(cameraPicker, animated: true, completion: nil)
    }
    
    func showAlbum() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .PhotoLibrary
        
        presentViewController(cameraPicker, animated: true, completion: nil)
    }
    
    // MARK: UIImagePickerControllerDelegate
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        dismissViewControllerAnimated(true, completion: nil)
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            filteredImage = image
            originalImage = image
            showOriginalImage()
            updateImagesSndMenu(image)
        }
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: Filter Menu
    @IBAction func onFilter(sender: UIButton) {
        if (sender.selected) {
            hideSecondaryMenu()
            sender.selected = false
        } else {
            hideEditMenu()
            showSecondaryMenu()
            editButton.selected = false
            sender.selected = true
        }
    }
    
    func showSecondaryMenu() {
        view.addSubview(secondaryMenu)
        
        let bottomConstraint = secondaryMenu.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let leftConstraint = secondaryMenu.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let rightConstraint = secondaryMenu.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        let heightConstraint = secondaryMenu.heightAnchor.constraintEqualToConstant(44)
        
        NSLayoutConstraint.activateConstraints([bottomConstraint, leftConstraint, rightConstraint, heightConstraint])
        
        view.layoutIfNeeded()
        
        self.secondaryMenu.alpha = 0
        UIView.animateWithDuration(0.4) {
            self.secondaryMenu.alpha = 1.0
        }
    }

    func hideSecondaryMenu() {
        UIView.animateWithDuration(0.4, animations: {
            self.secondaryMenu.alpha = 0
            }) { completed in
                if completed == true {
                    self.secondaryMenu.removeFromSuperview()
                }
        }
    }
    
    func onRed(sender: UIImageView) {
        currentFilter = "red"
        filteredImage = filters.filterImage(filteredImage!, filterColor: currentFilter, idx: intensitySlider.value)
        print("red selected")
        compareButton.enabled = true
        showFilteredImage()
    }
    
    func onGreen(sender: UIImageView) {
        currentFilter = "green"
        filteredImage = filters.filterImage(filteredImage!, filterColor: currentFilter, idx: intensitySlider.value)
        print("green selected")
        compareButton.enabled = true
        showFilteredImage()
    }
    
    func onBlue(sender: UIImageView) {
        currentFilter = "blue"
        filteredImage = filters.filterImage(filteredImage!, filterColor: currentFilter, idx: intensitySlider.value)
        print("blue selected")
        compareButton.enabled = true
        showFilteredImage()
    }
    
    func onYellow(sender: UIImageView) {
        currentFilter = "yellow"
        filteredImage = filters.filterImage(filteredImage!, filterColor: currentFilter, idx: intensitySlider.value)
        print("yellow selected")
        compareButton.enabled = true
        showFilteredImage()
    }
    
    func onPurple(sender: UIImageView) {
        currentFilter = "purple"
        filteredImage = filters.filterImage(filteredImage!, filterColor: currentFilter, idx: intensitySlider.value)
        print("purple selected")
        compareButton.enabled = true
        showFilteredImage()
    }
    

    //Mark: Compare
    @IBAction func onCompare(sender: UIButton) {
        if(sender.selected){
            showFilteredImage()
            sender.selected = false
        } else {
            showOriginalImage()
            sender.selected = true
        }
    }
    
    //Mark: Touch image
    func imageViewSingleTap(){
        
        switch gestureRecognizer.state {
        case .Began:
            print("UIGestureRecognizerState.Began")
        case .Ended:
            print("UIGestureRecognizerState.Ended")
        case .Changed:
            print("UIGestureRecognizerState.Changed")
        case .Cancelled:
            print("UIGestureRecognizerState.Cancelled")
        case .Failed:
            print("UIGestureRecognizerState.Failed")
        case .Possible:
            print("UIGestureRecognizerState.Possible")
        }
        
        if(isShowingFiltered){
            showOriginalImage()
            print("single tap: original")
        } else {
            showFilteredImage()
            print("single tap: filtered")
        }
    }
    
    //Mark: Original overlay
    func showOriginalOverlay(){
        print("show original overlay")
        self.originalOverlay?.alpha = 0.5
    }
    
    func hideOriginalOverlay(){
        print("hide original overlay")
        self.originalOverlay?.alpha = 0
    }
    
    //Mark: Show original/filtered image
    func showOriginalImage(){
        editButton.enabled = false
        secondImageView.image = firstImageView.image
        firstImageView.image = originalImage
        isShowingFiltered = false
        showOriginalOverlay()
        //Animation
        firstImageView.alpha = 0.0
        secondImageView.alpha = 1.0
        UIView.animateWithDuration(0.4) {
            self.firstImageView.alpha = 1.0
            self.secondImageView.alpha = 0.0
        }
    }
    
    func showFilteredImage(){
        editButton.enabled = true
        secondImageView.image = firstImageView.image
        firstImageView.image = filteredImage
        isShowingFiltered = true
        hideOriginalOverlay()
        //Animation
        firstImageView.alpha = 0.0
        secondImageView.alpha = 1.0
        UIView.animateWithDuration(0.4) {
            self.firstImageView.alpha = 1.0
            self.secondImageView.alpha = 0.0
        }
    }
    
    func updateImagesSndMenu(img: UIImage){
        //Red
        redButton.image = img
        redButton.image = filters.filterImage(redButton.image!, filterColor: "red", idx: intensitySlider.value)
        redButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onRed:"))
        redButton.userInteractionEnabled = true
        //Green
        greenButton.image = img
        greenButton.image = filters.filterImage(redButton.image!, filterColor: "green", idx: intensitySlider.value)
        greenButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onGreen:"))
        greenButton.userInteractionEnabled = true
        //Blue
        blueButton.image = img
        blueButton.image = filters.filterImage(redButton.image!, filterColor: "blue", idx: intensitySlider.value)
        blueButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onBlue:"))
        blueButton.userInteractionEnabled = true
        //Yellow
        yellowButton.image = img
        yellowButton.image = filters.filterImage(redButton.image!, filterColor: "yellow", idx: intensitySlider.value)
        yellowButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onYellow:"))
        yellowButton.userInteractionEnabled = true
        //Purple
        purpleButton.image = img
        purpleButton.image = filters.filterImage(redButton.image!, filterColor: "purple", idx: intensitySlider.value)
        purpleButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onPurple:"))
        purpleButton.userInteractionEnabled = true
    }
    
    @IBAction func onEdit(sender: UIButton) {
        if (sender.selected) {
            hideEditMenu()
            sender.selected = false
        } else {
            hideSecondaryMenu()
            filterButton.selected = false
            showEditMenu()
            sender.selected = true
        }
    }
    
    func showEditMenu() {
        view.addSubview(editMenu)
        
        let bottomConstraint = editMenu.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let leftConstraint = editMenu.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let rightConstraint = editMenu.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        let heightConstraint = editMenu.heightAnchor.constraintEqualToConstant(44)
        
        NSLayoutConstraint.activateConstraints([bottomConstraint, leftConstraint, rightConstraint, heightConstraint])
        
        view.layoutIfNeeded()
        
        self.editMenu.alpha = 0
        UIView.animateWithDuration(0.4) {
            self.editMenu.alpha = 1.0
        }
    }
    
    func hideEditMenu() {
        UIView.animateWithDuration(0.4, animations: {
            self.editMenu.alpha = 0
            }) { completed in
                if completed == true {
                    self.editMenu.removeFromSuperview()
                }
        }
    }
    @IBAction func onSlider(sender: UISlider) {
        intensityValue.text = String(intensitySlider.value)
        firstImageView.image  = filters.filterImage(filteredImage!, filterColor: currentFilter, idx: intensitySlider.value)
    }
}

