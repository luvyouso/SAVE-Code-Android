import UIKit

//function to convert RGB values into HSV values : RGBtoHSV

public func RGBtoHSV (red: Int,green: Int, blue: Int)->[Double]{
    let red_value = Double(red) / 255
    let green_value = Double(green) / 255
    let blue_value = Double(blue) / 255
    
    let max_value = max(red_value,blue_value,green_value)
    let min_value = min(red_value,blue_value,green_value)
    let delta = max_value - min_value
    
    var H_value: Double
    if delta == 0 {
        H_value = 0
    }
    else {
        if max_value == red_value{
            H_value = 60 * ((green_value  - blue_value) / delta)
        }
        else{
            if max_value == green_value{
                H_value = 60 * (((blue_value  - red_value) / delta) + 2)
            }
            else {
                H_value = 60 * (((red_value  - green_value) / delta) + 4)
            }
        }
    }
    
    if (H_value < 0){
        H_value += 360
    }
    
    let S_value: Double
    if max_value == 0 {
        S_value = 0
    }
    else {
        S_value = (delta / max_value)
    }
    
    let V_value: Double = max_value
    
    return [H_value,S_value,V_value]
}

//function to convert HSV values into RGB values : RGBtoHSV

public func HSVtoRGB (H:Double, S:Double, V:Double) ->[UInt8]{
    let H_value = H / 60
    let dec_H = floor(H_value)
    let fract_H = H_value - dec_H
    let p_value = V * (1 - S)
    let q_value = V * (1 - S * fract_H)
    let t_value = V * (1 - S * (1 - fract_H))
    
    var red_value: Double
    var green_value: Double
    var blue_value: Double
    
    if (S == 0) {
        red_value = V
        green_value = V
        blue_value = V
    }
    
    switch dec_H {
    case 0:
        red_value = V
        green_value = t_value
        blue_value = p_value
    case 1:
        red_value = q_value
        green_value = V
        blue_value = p_value
    case 2:
        red_value = q_value
        green_value = V
        blue_value = t_value
    case 3:
        red_value = p_value
        green_value = q_value
        blue_value = V
    case 4:
        red_value = t_value
        green_value = p_value
        blue_value = V
    default:
        red_value = V
        green_value = p_value
        blue_value = q_value
    }
    
    
    let red = UInt8(255 * (red_value))
    let green = UInt8(255 * (green_value))
    let blue = UInt8(255 * (blue_value))
    
    return([red,green,blue])
}