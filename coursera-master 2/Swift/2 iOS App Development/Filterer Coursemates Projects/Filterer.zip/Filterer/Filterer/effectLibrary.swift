import UIKit


public func negative(imagein: UIImage, level: Int)->UIImage{
    let rgbaImage = RGBAImage(image: imagein)!
    
    let numberOfpixel = rgbaImage.pixels.count - 1
    
    
    //RGB negative effect
    
    for i in 0...numberOfpixel {
        var monpixel = rgbaImage.pixels[i]
        //get the RGBA values for the pixel
        let red_value = Int(monpixel.red)
        let blue_value = Int(monpixel.blue)
        let green_value = Int(monpixel.green)
        
        //factor between 0 and 1
        let factor = Double(level) / 100
        
        let new_red = Int(Double(255 - red_value) * factor)
        let new_blue = Int(Double(255 - blue_value) * factor)
        let new_green = Int(Double(255 - green_value) * factor)
        
        monpixel.red = UInt8(new_red)
        monpixel.green = UInt8(new_green)
        monpixel.blue = UInt8(new_blue)
        
        //modifie l'image
        rgbaImage.pixels[i]=monpixel
    }
    let imageOut = rgbaImage.toUIImage()
    return imageOut!
}


public func brightness(imagein: UIImage, level: Int)->UIImage{
    let rgbaImage = RGBAImage(image: imagein)!
    
    let numberOfpixel = rgbaImage.pixels.count - 1
    
    for i in 0...numberOfpixel {
        var mypixel = rgbaImage.pixels[i]
        //get the RGBA values for the pixel
        let red_value = Int(mypixel.red)
        let blue_value = Int(mypixel.blue)
        let green_value = Int(mypixel.green)
        //compute the average of the RBA value
        //Change the RGB values
        //modification between
        
        //factor between 0 and 255
        let factor = Int((Double(level) / 100) * 255)
        
        let new_red = red_value + factor
        let new_green = green_value + factor
        let new_blue = blue_value + factor
        mypixel.red = UInt8(max(0,min(255,new_red)))
        mypixel.green = UInt8(max(0,min(255,new_green)))
        mypixel.blue = UInt8(max(0,min(255,new_blue)))
        //modifie l'image
        rgbaImage.pixels[i]=mypixel
        
    }
    let imageOut = rgbaImage.toUIImage()
    return imageOut!
}

public func saturation(imagein: UIImage, level: Int)->UIImage{
    let rgbaImage = RGBAImage(image: imagein)!
    
    
    let numberOfpixel = rgbaImage.pixels.count - 1
    
    
    for i in 0...numberOfpixel {
        var monpixel = rgbaImage.pixels[i]
        
        //get the RGBA values for the pixel
        let red_value = Int(monpixel.red)
        let blue_value = Int(monpixel.blue)
        let green_value = Int(monpixel.green)
        
        //factor between -1 and +1
        let factor = (Double(level - 50) / 50)
        
        let convert_RGB = RGBtoHSV(red_value, green: green_value, blue: blue_value)
        
        let H_value = convert_RGB[0]
        var S_value = convert_RGB[1] + factor
        if S_value > 1 {
            S_value = 1
        }
        if S_value < 0{
            S_value = 0
        }
        let V_value = convert_RGB[2]
        
        let convert_HSV = HSVtoRGB(H_value, S: S_value, V: V_value)
        monpixel.red = convert_HSV[0]
        monpixel.green = convert_HSV[1]
        monpixel.blue = convert_HSV[2]
        
        
        //modifie l'image
        rgbaImage.pixels[i]=monpixel
    }
    let imageOut = rgbaImage.toUIImage()
    return imageOut!
}

public func grayscale(imagein: UIImage, level: Int)->UIImage{
    let rgbaImage = RGBAImage(image: imagein)!
    
    
    let numberOfpixel = rgbaImage.pixels.count - 1
    
    //factor between -255 and +255
    let factor = Int((Double(level - 50) / 50) * 255)
    
    for i in 0...numberOfpixel {
        var monpixel = rgbaImage.pixels[i]
        //get the RGBA values for the pixel
        let red_value = Int(monpixel.red)
        let blue_value = Int(monpixel.blue)
        let green_value = Int(monpixel.green)
        //compute the grey value (average of the RBA values)
        //let grey_value = Int((red_value + green_value + blue_value)/3)
        let grey_value = max(0,min(255,Int((red_value + green_value + blue_value)/3) + factor))
        //Change the RGB values
        monpixel.red = UInt8(grey_value)
        monpixel.green = UInt8(grey_value)
        monpixel.blue = UInt8(grey_value)
        //modifie l'image
        rgbaImage.pixels[i]=monpixel
        
    }
    let imageOut = rgbaImage.toUIImage()
    return imageOut!
}


public func warhol (imagein: UIImage, level: Int)->UIImage{
    let rgbaImage = RGBAImage(image: imagein)!
    let numberOfPixel = rgbaImage.pixels.count - 1
    //loop to have access to all the pixels
    for i in 0...numberOfPixel {
        var mypixel = rgbaImage.pixels[i]
        //get the RGBA values for the pixel
        let red_value = Int(mypixel.red)
        let blue_value = Int(mypixel.blue)
        let green_value = Int(mypixel.green)
        //compute the average of the RBA values
        let average = Int((red_value + green_value + blue_value)/3)
        
        //factor between 0 and 1
        let factor: Double = Double(level) / 100
        //if the average pixel value is higher than 122 all the pixels are colored in yellowish color
        if average >= 122{
            let new_red = 247 + Int(Double(red_value) * (1 - factor))
            let new_green = 249 + Int(Double(green_value) * (1 - factor))
            let new_blue = 37 + Int(Double(blue_value) * (1 - factor))
            mypixel.red = UInt8(max(0,min(255,new_red)))
            mypixel.green = UInt8(max(0,min(255,new_green)))
            mypixel.blue = UInt8(max(0,min(255,new_blue)))
            
        }
        else {
            //if the average pixel value is lower than 122 all the pixels are colored in blueish color
            let new_red = 36 + Int(Double(red_value) * (1 - factor))
            let new_green = 123 + Int(Double(green_value) * (1 - factor))
            let new_blue = 244 + Int(Double(blue_value) * (1 - factor))
            mypixel.red = UInt8(max(0,min(255,new_red)))
            mypixel.green = UInt8(max(0,min(255,new_green)))
            mypixel.blue = UInt8(max(0,min(255,new_blue)))
        }
        //modifie l'image
        rgbaImage.pixels[i]=mypixel
        
    }
    let imageOut = rgbaImage.toUIImage()
    return imageOut!
}

public func sepia (imagein: UIImage, level: Int)->UIImage{
    let rgbaImage = RGBAImage(image: imagein)!
    let numberOfpixel = rgbaImage.pixels.count - 1
    
    
    //RGB negative effect
    
    for i in 0...numberOfpixel {
        var monpixel = rgbaImage.pixels[i]
        
        //get the RGBA values for the pixel
        let red_value = Double(monpixel.red)
        let blue_value = Double(monpixel.blue)
        let green_value = Double(monpixel.green)
        
        //factor between 0 and +1
        let factor = (Double(level) / 100)
        
        let new_red = (red_value * 0.393 + green_value * 0.769 + blue_value * 0.189) * factor
        let new_green = (red_value * 0.349 + green_value * 0.686 + blue_value * 0.168) * factor
        let new_blue = (red_value * 0.272 + green_value * 0.534 + blue_value * 0.131) * factor
        
        let sepia_red = Int(max(0,min(255,new_red)))
        let sepia_green = Int(max(0,min(255,new_green)))
        let sepia_blue = Int(max(0,min(255,new_blue)))
        
        monpixel.red = UInt8(sepia_red)
        monpixel.green = UInt8(sepia_green)
        monpixel.blue = UInt8(sepia_blue)
        
        //modifie l'image
        rgbaImage.pixels[i]=monpixel
    }
    
    let imageOut = rgbaImage.toUIImage()
    return imageOut!
}

public extension UIView {
    
    /**
     Fade in a view with a duration
     
     - parameter duration: custom animation duration
     */
    func fadeIn(duration duration: NSTimeInterval = 0.4) {
        UIView.animateWithDuration(duration, animations: {
            self.alpha = 1.0
        })
    }
    
    /**
     Fade out a view with a duration
     
     - parameter duration: custom animation duration
     */
    func fadeOut(duration duration: NSTimeInterval = 0.7) {
        UIView.animateWithDuration(duration, animations: {
            self.alpha = 0.0
        })
    }
    
}