//
//  ViewController.swift
//  Filterer
//
//  Created by Cyril d'Arbaumont on 2015-11-11..
//  Copyright © 2015 CdA. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    let sectionInsets = UIEdgeInsets(top: 10.0, left: 10.0, bottom: 10.0, right: 10.0)
    
    var filteredImage: UIImage?
    var transitionImage: UIImage?
    var filterType: String?
    
    var orignalImage = UIImage(named: "scenery")
    
    var filtersImage: [UIImage] = [
        UIImage(named: "gray")!,
        UIImage(named: "negative")!,
        UIImage(named: "warhol")!,
        UIImage(named: "sepia")!,
        UIImage(named: "brightness")!,
        UIImage(named: "saturation")!
    ]
    
    var filtersName: [String] = [
        "Gray Scale",
        "Negative",
        "Warhol",
        "Sepia",
        "Brightness",
        "Saturation"
    ]
    
    @IBOutlet var originalLabel: UIView!
    @IBOutlet var intensitySlider: UISlider!
    @IBOutlet var SliderView: UIView!
    @IBOutlet var editButton: UIButton!
    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var filterMenu: UIView!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var bottomMenu: UIView!
    @IBOutlet var filterButton: UIButton!
    @IBOutlet var transitionImageView: UIImageView!
    @IBOutlet var compareButton: UIButton!

    //---------------Compare Button-------------------------
    @IBAction func onCompare(sender: UIButton) {
        if(sender.selected){
            self.transitionImageView.fadeOut()
            self.imageView.fadeIn()
            
            if (transitionImageView.alpha == 1){
                transitionImageView.hidden = true
            }
            hideOriginalLabel()
            sender.selected = false
        }
        else{
            self.transitionImageView.image = orignalImage
            
            self.transitionImageView.hidden = false
            
            self.imageView.alpha = 1
            self.transitionImageView.alpha = 0
            
            self.imageView.fadeOut()
            self.transitionImageView.fadeIn()
            
            showOriginalLabel()
            sender.selected = true
        }
    }
    
    
    //-----------------Silder-----------------------------
    @IBAction func onSlider(sender: UISlider) {
        sender.minimumTrackTintColor = UIColor.yellowColor()
        sender.continuous = true
        let currentValue = Int(sender.value)
        switch filterType! {
        case "Negative":
            imageView.image = negative(orignalImage!,level: currentValue)
        case "Gray Scale":
            imageView.image = grayscale(orignalImage!,level: currentValue)
        case "Brightness":
            imageView.image = brightness(orignalImage!, level: currentValue)
        case "Warhol":
            imageView.image = warhol(orignalImage!, level: currentValue)
        case "Sepia":
            imageView.image = sepia(orignalImage!, level: currentValue)
        default:
            imageView.image = saturation(orignalImage!, level: currentValue)
        }
        filteredImage = imageView.image
    }
    
    func showSliderView () {
        //importation de secondarymenu dans view
        view.addSubview(SliderView)
        
        //definition des contraintes de secondaryMenu
        let bottomConstraint = SliderView.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let leftConstraint = SliderView.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let rightConstraint = SliderView.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        let heighConstraint = SliderView.heightAnchor.constraintEqualToConstant(44)
        //active les contraintes
        NSLayoutConstraint.activateConstraints([bottomConstraint, leftConstraint,rightConstraint,heighConstraint])
        //les edite
        view.layoutIfNeeded()
        self.SliderView.alpha = 0
        UIView.animateWithDuration(0.4){
            self.SliderView.alpha = 1
        }
    }
    
    
    //-----------------Edit Button------------------------------
    @IBAction func onEdit(sender: UIButton) {
        if (sender.selected == false){
            self.filterButton.selected = false
            hideFilterMenu()
            showSliderView()
            sender.selected = true
        }
        else{
            showFilterMenu()
            self.SliderView.removeFromSuperview()
            sender.selected = false
        }
    }

    


    //--------------Pressing the filtered image displayed the original image -----------------------
    @IBAction func onPressImage(sender: UILongPressGestureRecognizer) {
        if (filteredImage != nil){
            if (sender.state == UIGestureRecognizerState.Began){
                self.transitionImageView.image = orignalImage
                
                self.transitionImageView.hidden = false
                
                self.imageView.alpha = 1
                self.transitionImageView.alpha = 0
                
                self.imageView.fadeOut()
                self.transitionImageView.fadeIn()
                
                showOriginalLabel()
            }
            if (sender.state == UIGestureRecognizerState.Ended){
                
                self.transitionImageView.fadeOut()
                self.imageView.fadeIn()

                if (transitionImageView.alpha == 0){
                    transitionImageView.hidden = true
                }
                hideOriginalLabel()
            }
        }
    }
    
    func showOriginalLabel(){
        view.addSubview(originalLabel)
//        var BottomConstraint: NSLayoutConstraint
//        if (filterMenu.superview != nil){
//                   BottomConstraint = originalLabel.bottomAnchor.constraintEqualToAnchor(filterMenu.topAnchor)
//        }
//        else{
//            BottomConstraint = originalLabel.bottomAnchor.constraintEqualToAnchor(SliderView.topAnchor)
//        }
        let TopConstraint = originalLabel.topAnchor.constraintEqualToAnchor(view.topAnchor)
        let BottomConstraint = originalLabel.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let LeftConstraint = originalLabel.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let RightConstraint = originalLabel.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        NSLayoutConstraint.activateConstraints([LeftConstraint, RightConstraint, BottomConstraint, TopConstraint])
        view.layoutIfNeeded()
    }
    
    func hideOriginalLabel(){
        self.originalLabel.removeFromSuperview()
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        originalLabel.translatesAutoresizingMaskIntoConstraints = false
        originalLabel.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0)
        
        SliderView.translatesAutoresizingMaskIntoConstraints = false
        SliderView.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0)
        
        filterMenu.translatesAutoresizingMaskIntoConstraints = false
        filterMenu.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0)
        
        transitionImageView.translatesAutoresizingMaskIntoConstraints = false
        
        editButton.hidden = true
        compareButton.hidden = true
        imageView.userInteractionEnabled = true
        transitionImageView.userInteractionEnabled = true
        transitionImageView.hidden = true
        
        collectionView.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0)
    }

    // MARK: Share
    @IBAction func onShare(sender: UIButton) {
        let activityController = UIActivityViewController(activityItems: ["Check out our really cool app", imageView.image!], applicationActivities: nil)
        presentViewController(activityController, animated: true, completion: nil)
    }
    
    // MARK: New Photo
    @IBAction func onNewPhoto(sender: UIButton) {
        let actionSheet = UIAlertController(title: "New Photo", message: nil, preferredStyle: .ActionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .Default, handler: { action in
            self.showCamera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Album", style: .Default, handler: { action in
            self.showAlbum()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .Cancel, handler: nil))
        
        self.presentViewController(actionSheet, animated: true, completion: nil)
    }
    
    func showCamera() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .Camera
        
        presentViewController(cameraPicker, animated: true, completion: nil)
    }
    
    func showAlbum() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .PhotoLibrary
        
        presentViewController(cameraPicker, animated: true, completion: nil)
    }
    
    // MARK: UIImagePickerControllerDelegate
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        dismissViewControllerAnimated(true, completion: nil)
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            //Compare and edit buttons hidden
            editButton.hidden = true
            compareButton.hidden = true
            intensitySlider.value = 50
            
            if (filterButton.selected){
                hideFilterMenu()
                filterButton.selected = false
            }
            if (SliderView.superview != nil){
                 SliderView.removeFromSuperview()
            }
            imageView.image = image
            orignalImage = image
        }
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    //---------------------Filter Menu-------------------------------------
    @IBAction func onFilter(sender: UIButton) {
        if (sender.selected){
            hideFilterMenu()
            sender.selected = false
            editButton.hidden = true
            compareButton.hidden = true
        }
        else{
            showFilterMenu()
            sender.selected = true
            if (self.editButton.selected){
                self.editButton.selected = false
                self.intensitySlider.value = 50
                self.SliderView.removeFromSuperview()
            }
        }
    }
    
    func showFilterMenu () {
        //importation de secondarymenu dans view
        view.addSubview(filterMenu)
        
        //definition des contraintes de secondaryMenu
        let bottomConstraint = filterMenu.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let leftConstraint = filterMenu.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let rightConstraint = filterMenu.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        let heighConstraint = filterMenu.heightAnchor.constraintEqualToConstant(100)
        //active les contraintes
        NSLayoutConstraint.activateConstraints([bottomConstraint, leftConstraint,rightConstraint,heighConstraint])
        //les edite
        view.layoutIfNeeded()
        self.filterMenu.alpha = 0
        UIView.animateWithDuration(0.4){
            self.filterMenu.alpha = 1
        }
    }
    
    func hideFilterMenu (){
        UIView.animateWithDuration(0.4, animations: {
            self.filterMenu.alpha = 1
            }) {completed in
                if completed == true {
                    self.filterMenu.removeFromSuperview()
                }
        }
    }



    //-------COLLECTIONVIEW------
    //number of cells in the collection view
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filtersImage.count
    }
    
    //creation of the cells with the photo and the label
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell: MyCollectionViewCell = collectionView.dequeueReusableCellWithReuseIdentifier("Cell", forIndexPath: indexPath) as! MyCollectionViewCell
        cell.imageView.image = filtersImage[indexPath.row]
        cell.label.text = filtersName[indexPath.row]
        cell.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0)
        cell.button.addTarget(self, action: "buttonPressed:", forControlEvents: .TouchUpInside)
        return cell
    }
    
    
    func collectionView(collectionView: UICollectionView!,
        layout collectionViewLayout: UICollectionViewLayout!,
        insetForSectionAtIndex section: Int) -> UIEdgeInsets {
            return sectionInsets
    }
    
    //    Button action a the cell of the CollectionView
    
    func buttonPressed(button: UIButton) {
        let touchPoint = collectionView.convertPoint(CGPoint.zero, fromView: button)
        if let indexPath = collectionView.indexPathForItemAtPoint(touchPoint) {
            filterType = filtersName[indexPath.row]
            switch filterType! {
            case "Negative":
                filteredImage = negative(orignalImage!,level: Int(intensitySlider.value))
            case "Gray Scale":
                filteredImage = grayscale(orignalImage!,level: Int(intensitySlider.value))
            case "Brightness":
                filteredImage = brightness(orignalImage!, level: Int(intensitySlider.value))
            case "Warhol":
                filteredImage = warhol(orignalImage!, level: Int(intensitySlider.value))
            case "Sepia":
                filteredImage = sepia(orignalImage!, level: Int(intensitySlider.value))
            default:
                filteredImage = saturation(orignalImage!, level: Int(intensitySlider.value))
            }
//            transitionImageView.image = imageView.image
            transitionImageView.image = imageView.image
            imageView.image = filteredImage
            
            self.transitionImageView.hidden = false
            
            self.imageView.alpha = 0
            self.transitionImageView.alpha = 1
            
            self.imageView.fadeIn()
            self.transitionImageView.fadeOut()
            
            editButton.hidden = false
            compareButton.hidden = false
        }
        
    }
    
}





