//
//  MyCollectionViewCell.swift
//  Filterer
//
//  Created by Cyril on 12/11/2015.
//  Copyright © 2015 UofT. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var label: UILabel!
    @IBOutlet var button: UIButton!
    
}
