#A simple iOS demo for YouTube API

This is a simple demo that shows you how to integrate your app with YouTube API. You can 
find the full tutorial here:

http://www.appcoda.com/youtube-api-ios-tutorial

To run the demo, you will need to create your own API key first and update the following line of code in ViewController.swift:

  var apiKey = "YOUR_API_KEY_HERE"
