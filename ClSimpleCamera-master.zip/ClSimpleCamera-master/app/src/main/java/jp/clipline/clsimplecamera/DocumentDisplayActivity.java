package jp.clipline.clsimplecamera;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class DocumentDisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_display);

        WebView webView = (WebView) findViewById(R.id.webView);
        webView.setWebViewClient(new DoNothingWebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.loadUrl(getIntent().getStringExtra("ASSETS_HTML_FILE"));
    }

    private class DoNothingWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, String url) {
            return true;
        }
    }

}