package jp.clipline.clsimplecamera;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class PermissionsWaitActivity extends AppCompatActivity {

    public static int PERMISSION_REQUEST_CODE = 1;
    public static final String TAG = "SimpleCamera";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions_wait);

        activityRequestPermissions(PERMISSION_REQUEST_CODE);
    }

    private boolean activityRequestPermissions(int requestCode) {
        if (Build.VERSION.SDK_INT >= 23) {
            ArrayList<String> permissions = CameraUtil.getSettingPermissions(this);
            boolean isRequestPermission = false;
            for (String permission : permissions) {
                if (!CameraUtil.hasSelfPermission(this, permission)) {
                    isRequestPermission = true;
                    break;
                }
            }
            if (isRequestPermission) {
                requestPermissions(permissions.toArray(new String[0]), requestCode);
                return true;
            }
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {

        Log.d(TAG,"@@@ onRequestPermissionsResult : Start @@@");
        if (requestCode == PERMISSION_REQUEST_CODE) {

            // 許可されたパーミッションがあるかを確認する
            boolean isSomethingGranted = false;
            for(int grantResult : grantResults) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    isSomethingGranted = true;
                    break;
                }
            }

            if (isSomethingGranted) {
                // 設定を変更してもらえた場合、処理を継続する
                IntentParameters intentParameters = new IntentParameters(getIntent(), CameraUtil.isStandardAspectHardWare(getWindowManager()));
                Intent intent = new Intent( getApplicationContext(), CameraActivity.class);
                intentParameters.apply(intent);
                startActivity(intent);
                overridePendingTransition(0,0);

                finish();
            } else {
                // 設定を変更してもらえなかった場合、終了
                Toast.makeText(this, getString(R.string.find_authority_to_user), Toast.LENGTH_LONG).show();
                finish();
            }
        }
        Log.d(TAG,"@@@ onRequestPermissionsResult : End @@@");
    }

}
